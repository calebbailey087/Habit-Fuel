import { pgTable, text, jsonb, integer, timestamp } from "drizzle-orm/pg-core";

export const habitFuelAccounts = pgTable("habit_fuel_accounts", {
  userId: text("user_id").primaryKey(),
  state: jsonb("state").notNull(),
  revision: integer("revision").notNull().default(1),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
