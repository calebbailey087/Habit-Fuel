---
name: Account ownership
description: Product decisions about private synced web profiles and existing device-only data.
---

Signed-in web/Home Screen profiles use separate, synced accounts. The user also explicitly requested an optional “Continue without an account” path with device-local guest data.

**Why:** People should be able to try and use the app without registering, while accounts keep personal data separate and available across devices. Older device logs have no verified account owner.

**How to apply:** Keep guest entry visible and independent of authentication. Do not silently assign guest or legacy browser data to whoever signs in first. Offer an explicit import and keep the original until the user chooses otherwise. Preserve ownership boundaries in caches, background refreshes, and account switches. Do not claim the native companion shares account data until that integration is implemented.
