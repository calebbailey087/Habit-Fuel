---
name: Phone access
description: Product decision supporting a browser-installed iPhone app alongside the native companion.
---

The user approved a shareable browser version that can be added to an iPhone Home Screen without Expo Go. Keep the native companion available separately.

**Why:** The requested phone-access workflow is to share a link from a Mac, open it in Safari, and install it as a Home Screen app.

**How to apply:** Keep the web experience usable independently of Expo. Explain browser limits rather than promising native Apple Health or pedometer access. Do not assume browser, Home Screen, desktop, or native data are synced unless a shared account/backend is actually implemented.
