---
name: Codegen exports
description: Orval request-body naming avoids generated Zod and TypeScript export collisions.
---

Use named OpenAPI components referenced by request bodies rather than anonymous inline objects for this workspace's API generation.

**Why:** Orval's runtime Zod validators and TypeScript body models can otherwise receive the same exported name. Regeneration also restores barrel exports, so manually narrowing the barrel does not fix the collision durably.

**How to apply:** Fix the schema naming at the OpenAPI source and regenerate. Do not patch generated files or repeatedly remove barrel exports.
