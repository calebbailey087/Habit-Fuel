import type { Profile } from './store';

export const activityOptions = [
  { label: 'Low movement', multiplier: 1.2 },
  { label: 'Lightly active', multiplier: 1.375 },
  { label: 'Moderately active', multiplier: 1.55 },
  { label: 'Very active', multiplier: 1.725 },
];
export const MIN_APPLY = 1200;

export type Estimate =
  | { kind: 'missing' }
  | { kind: 'minor' }
  | { kind: 'ok'; targetLow: number; targetHigh: number; maintenanceLow: number; maintenanceHigh: number; midpoint: number };

/** Mifflin-St Jeor resting estimate times activity factor, +/-500 kcal for about 1 lb/week. */
export function estimateCalories(p: Profile): Estimate {
  const inches = (p.heightFeet ?? 0) * 12 + (p.heightInches ?? 0);
  if (!p.ageYears || !inches || !p.weightPounds) return { kind: 'missing' };
  if (p.ageYears < 18) return { kind: 'minor' };
  const cm = inches * 2.54, kg = p.weightPounds / 2.20462;
  const factor = activityOptions.find(a => a.label === p.activityLevel)?.multiplier ?? 1.2;
  const adj = p.weightGoal === 'lose' ? -500 : p.weightGoal === 'gain' ? 500 : 0;
  const eqs = p.calorieEquation === 'range' ? ['female', 'male'] : [p.calorieEquation];
  const maint = eqs.map(e => Math.round((10 * kg + 6.25 * cm - 5 * p.ageYears! + (e === 'female' ? -161 : 5)) * factor));
  const targets = maint.map(m => m + adj);
  const targetLow = Math.min(...targets), targetHigh = Math.max(...targets);
  return { kind: 'ok', targetLow, targetHigh, maintenanceLow: Math.min(...maint), maintenanceHigh: Math.max(...maint), midpoint: Math.round((targetLow + targetHigh) / 2) };
}

export const rangeLabel = (lo: number, hi: number) => lo === hi ? `${lo.toLocaleString()} kcal/day` : `${lo.toLocaleString()}-${hi.toLocaleString()} kcal/day`;

export type MetricIssue = { field: 'age' | 'height' | 'weight'; message: string };

/** Flags missing or implausible adult metrics before any recommendation is shown. */
export function validateMetrics(p: Profile): MetricIssue[] {
  const issues: MetricIssue[] = [];
  const inches = (p.heightFeet ?? 0) * 12 + (p.heightInches ?? 0);
  if (!p.ageYears) issues.push({ field: 'age', message: 'Add your age.' });
  else if (p.ageYears > 110) issues.push({ field: 'age', message: 'Age looks off. Check the number.' });
  if (!inches) issues.push({ field: 'height', message: 'Add your height.' });
  else if (inches < 48 || inches > 96) issues.push({ field: 'height', message: 'Height should be between 4 ft and 8 ft.' });
  if (!p.weightPounds) issues.push({ field: 'weight', message: 'Add your weight.' });
  else if (p.weightPounds < 70 || p.weightPounds > 700) issues.push({ field: 'weight', message: 'Weight should be between 70 and 700 lb.' });
  return issues;
}

export type Recommendation =
  | { kind: 'invalid'; issues: MetricIssue[] }
  | { kind: 'minor' }
  | { kind: 'blocked'; calories: number }
  | { kind: 'ok'; calories: number; protein: number; carbs: number; fat: number; proteinPerKg: number; proteinCapped: boolean; kg: number; maintenance: number; reasoning: string[] };

/**
 * Adults only. Calories: Mifflin-St Jeor midpoint (or chosen equation) x activity, +/-500.
 * Protein ~1.6 g/kg maintain, 1.8 gain, 2.0 lose, capped at 35% of calories.
 * Fat 30% of calories. Carbs fill the remainder. Calories re-derived from rounded grams so they always add up.
 */
export function recommendTargets(p: Profile): Recommendation {
  const issues = validateMetrics(p);
  if (issues.length) return { kind: 'invalid', issues };
  if ((p.ageYears ?? 0) < 18) return { kind: 'minor' };
  const est = estimateCalories(p);
  if (est.kind !== 'ok') return { kind: 'invalid', issues: [] };
  const base = Math.round(est.midpoint / 10) * 10;
  if (base < MIN_APPLY) return { kind: 'blocked', calories: base };
  const kg = p.weightPounds! / 2.20462;
  const perKg = p.weightGoal === 'lose' ? 2 : p.weightGoal === 'gain' ? 1.8 : 1.6;
  const proteinCap = Math.floor((base * 0.35) / 4);
  const rawProtein = Math.round(kg * perKg);
  const protein = Math.min(rawProtein, proteinCap);
  const fat = Math.round((base * 0.3) / 9);
  const carbs = Math.max(0, Math.round((base - protein * 4 - fat * 9) / 4));
  const calories = protein * 4 + carbs * 4 + fat * 9;
  const maintenance = Math.round((est.maintenanceLow + est.maintenanceHigh) / 2);
  const reasoning = [
    `Maintenance is estimated around ${maintenance.toLocaleString()} kcal/day using Mifflin-St Jeor${p.calorieEquation === 'range' ? ' (midpoint of the female and male versions)' : ''} and your "${p.activityLevel}" activity level.`,
    p.weightGoal === 'maintain' ? 'Your direction is maintain, so no adjustment is added.' : `Your direction is ${p.weightGoal}, so roughly ${p.weightGoal === 'lose' ? '500 kcal is subtracted' : '500 kcal is added'} for about 1 lb per week.`,
    `Protein starts at ${perKg} g per kg of body weight (${kg.toFixed(1)} kg)${protein < rawProtein ? `, capped at 35% of calories (${protein} g)` : ''}.`,
    'Fat is set to about 30% of calories. Carbohydrates fill what remains.',
    'Calories shown are re-added from the rounded grams so the numbers stay consistent.',
  ];
  return { kind: 'ok', calories, protein, carbs, fat, proteinPerKg: perKg, proteinCapped: protein < rawProtein, kg, maintenance, reasoning };
}
