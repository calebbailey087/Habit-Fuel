export type FoodEntry = { id: string; dateKey: string; name: string; meal: string; time: string; calories: number; protein: number; carbs: number; fat: number; estimateSource: string; notes: string };
export type Exercise = { name: string; sets: number; reps: number; weight: number };
export type WorkoutEntry = { id: string; dateKey: string; name: string; type: string; durationMinutes: number; effort: string; caloriesBurnedEstimate: number; exercises: Exercise[] };
export type MealPreset = { id: string; name: string; meal: string; calories: number; protein: number; carbs: number; fat: number; notes: string };
export type Targets = { calories: number; protein: number; carbs: number; fat: number };
export type WeightGoal = 'lose' | 'maintain' | 'gain';
export type CalorieEquation = 'range' | 'female' | 'male';
export type Profile = {
  goal: string; experience: string; routineMode: string; daysAvailable: string[]; equipment: string[]; movementNotes: string; nutritionPreference: string; minutesAvailable: number;
  ageYears: number | null; heightFeet: number | null; heightInches: number | null; weightPounds: number | null; activityLevel: string; calorieEquation: CalorieEquation; weightGoal: WeightGoal;
  displayName: string;
};
export type PlanItem = { id: string; name: string; day: string; durationMinutes: number; completed: boolean };
export type ThemeName = 'classic' | 'dark' | 'lavender';
export type Store = { foods: FoodEntry[]; workouts: WorkoutEntry[]; presets: MealPreset[]; targets: Targets; profile: Profile; plan: PlanItem[]; theme: ThemeName; legacyImported?: boolean };
export type Shared = { store: Store; update: (patch: Partial<Store>) => void; notify: (message: string) => void; todayKey: string };

export const STORAGE_KEY = 'habit-fuel-v1';

export function getLocalDateKey(date: Date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
export function dateFromKey(key: string) { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); }
export function shiftKey(key: string, days: number) { const d = dateFromKey(key); d.setDate(d.getDate() + days); return getLocalDateKey(d); }
export function formatKey(key: string, opts: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' }) { return dateFromKey(key).toLocaleDateString(undefined, opts); }
export const timeLabel = () => new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
export const newId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
export const money = (n: number) => Math.round(n).toLocaleString();

export const defaultProfile: Profile = {
  goal: 'Build consistency', experience: 'Some experience', routineMode: 'Adapt my routine', daysAvailable: ['Mon', 'Wed', 'Sat'], equipment: ['Dumbbells', 'Bodyweight'], movementNotes: '', nutritionPreference: 'No preference', minutesAvailable: 35,
  ageYears: null, heightFeet: null, heightInches: null, weightPounds: null, activityLevel: 'Lightly active', calorieEquation: 'range', weightGoal: 'maintain', displayName: '',
};

export const defaultTargets: Targets = { calories: 2000, protein: 0, carbs: 0, fat: 0 };
const THEMES: ThemeName[] = ['classic', 'dark', 'lavender'];

/** A brand-new account: no demo logs, no sample plan. */
export function emptyStore(): Store {
  return { foods: [], workouts: [], presets: [], targets: { ...defaultTargets }, profile: { ...defaultProfile, daysAvailable: [...defaultProfile.daysAvailable], equipment: [...defaultProfile.equipment] }, plan: [], theme: 'classic' };
}

const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : Number(v) || 0);
const arr = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);

/** Normalizes any stored shape (remote or legacy) without inventing entries. */
export function migrateStore(raw: unknown): Store {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Partial<Store> & Record<string, unknown>;
  const k = getLocalDateKey();
  const base = emptyStore();
  const store: Store = {
    foods: arr<FoodEntry>(r.foods).map(f => ({ ...f, id: String(f.id ?? newId()), dateKey: f.dateKey || k, notes: f.notes ?? '', estimateSource: f.estimateSource ?? 'manual', calories: num(f.calories), protein: num(f.protein), carbs: num(f.carbs), fat: num(f.fat) })),
    workouts: arr<WorkoutEntry>(r.workouts).map(w => ({ ...w, id: String(w.id ?? newId()), dateKey: w.dateKey || k, exercises: Array.isArray(w.exercises) ? w.exercises : [] })),
    presets: arr<MealPreset>(r.presets),
    targets: { ...base.targets, ...((r.targets as Targets | undefined) ?? {}) },
    profile: { ...base.profile, ...((r.profile as Profile | undefined) ?? {}) },
    plan: arr<PlanItem>(r.plan),
    theme: THEMES.includes(r.theme as ThemeName) ? (r.theme as ThemeName) : 'classic',
  };
  if (typeof store.profile.displayName !== 'string') store.profile.displayName = '';
  if (r.legacyImported === true) store.legacyImported = true;
  return store;
}

/** Read-only peek at the old on-device store. Never written or removed. */
export function readLegacyStore(): Store | null {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return null;
    const s = migrateStore(JSON.parse(saved));
    return s.foods.length + s.workouts.length + s.presets.length + s.plan.length ? s : null;
  } catch { return null; }
}

const sig = (o: Record<string, unknown>, keys: string[]) => keys.map(key => String(o[key] ?? '')).join('|').toLowerCase();
function mergeList<T extends { id: string }>(current: T[], incoming: T[], keys: string[]) {
  const ids = new Set(current.map(x => x.id));
  const sigs = new Set(current.map(x => sig(x as unknown as Record<string, unknown>, keys)));
  const added: T[] = [];
  for (const item of incoming) {
    const s = sig(item as unknown as Record<string, unknown>, keys);
    if (sigs.has(s)) continue;
    sigs.add(s);
    added.push(ids.has(item.id) ? { ...item, id: newId() } : item);
  }
  return { list: [...current, ...added], added: added.length };
}

/** Explicit, consented merge of legacy browser entries into the account. Deduplicates by content. */
export function mergeLegacy(current: Store, legacy: Store): { store: Store; added: number } {
  const foods = mergeList(current.foods, legacy.foods, ['dateKey', 'name', 'meal', 'time', 'calories']);
  const workouts = mergeList(current.workouts, legacy.workouts, ['dateKey', 'name', 'durationMinutes', 'caloriesBurnedEstimate']);
  const presets = mergeList(current.presets, legacy.presets, ['name', 'meal', 'calories']);
  const plan = mergeList(current.plan, legacy.plan, ['name', 'day', 'durationMinutes']);
  return { store: { ...current, foods: foods.list, workouts: workouts.list, presets: presets.list, plan: plan.list, legacyImported: true }, added: foods.added + workouts.added + presets.added + plan.added };
}

export function foodTotals(foods: FoodEntry[]) {
  return foods.reduce((a, f) => ({ calories: a.calories + num(f.calories), protein: a.protein + num(f.protein), carbs: a.carbs + num(f.carbs), fat: a.fat + num(f.fat) }), { calories: 0, protein: 0, carbs: 0, fat: 0 });
}
