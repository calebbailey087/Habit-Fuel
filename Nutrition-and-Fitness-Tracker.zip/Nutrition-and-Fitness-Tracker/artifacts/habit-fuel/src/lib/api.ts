import type { Store } from './store';

export type Snapshot = { state: unknown | null; revision: number; updatedAt: string | null };
export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export class OfflineError extends Error {}

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
export const STATE_URL = `${basePath}/api/habit-fuel/state`;

async function request(init: RequestInit & { signal?: AbortSignal }): Promise<Snapshot> {
  let res: Response;
  try {
    res = await fetch(STATE_URL, { ...init, credentials: 'include', cache: 'no-store', headers: { Accept: 'application/json', ...(init.body ? { 'Content-Type': 'application/json' } : {}) } });
  } catch (e) {
    if ((e as Error)?.name === 'AbortError') throw e;
    throw new OfflineError('Network unavailable');
  }
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try { const body = await res.json(); if (body?.error) msg = String(body.error); } catch { /* ignore */ }
    throw new ApiError(res.status, msg);
  }
  return res.json() as Promise<Snapshot>;
}

export const fetchState = (signal?: AbortSignal) => request({ method: 'GET', signal });
export const putState = (state: Store, expectedRevision: number, signal?: AbortSignal) =>
  request({ method: 'PUT', body: JSON.stringify({ state, expectedRevision }), signal });
