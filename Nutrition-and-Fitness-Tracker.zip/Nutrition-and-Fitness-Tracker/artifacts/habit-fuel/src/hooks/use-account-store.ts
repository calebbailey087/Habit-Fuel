import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError, fetchState, OfflineError, putState, type Snapshot } from '@/lib/api';
import { emptyStore, migrateStore, type Store } from '@/lib/store';

export type SyncStatus = 'loading' | 'load-error' | 'synced' | 'pending' | 'saving' | 'offline' | 'error' | 'conflict' | 'auth';
type CacheShape = { store: Store; revision: number; dirty: boolean; savedAt: number };

const SAVE_DELAY = 900;
const REFRESH_MS = 30_000;
const cacheKeyFor = (userId: string) => `habit-fuel-cache:${userId}`;

function readCache(key: string): CacheShape | null {
  try { const raw = localStorage.getItem(key); if (!raw) return null; const c = JSON.parse(raw); return c && typeof c === 'object' ? { ...c, store: migrateStore(c.store) } : null; }
  catch { return null; }
}

/**
 * Owner-scoped account store. Remount with key={userId}.
 * Rules: hydrate from server before any write; serialized debounced PUTs with expectedRevision;
 * never replace dirty local state with remote; 409 keeps the draft and blocks writes until the user chooses.
 */
export function useAccountStore(userId: string) {
  const cacheKey = cacheKeyFor(userId);
  const [store, setStoreState] = useState<Store | null>(null);
  const [status, setStatusState] = useState<SyncStatus>('loading');
  const [message, setMessage] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [cacheError, setCacheError] = useState<string | null>(null);

  const storeRef = useRef<Store | null>(null);
  const revisionRef = useRef(0);
  const dirtyRef = useRef(false);
  const editSeq = useRef(0);
  const inflight = useRef(false);
  const hydrated = useRef(false);
  const conflictRef = useRef(false);
  const statusRef = useRef<SyncStatus>('loading');
  const alive = useRef(true);
  const timer = useRef<number | undefined>(undefined);
  const controller = useRef<AbortController | null>(null);

  const setStatus = (s: SyncStatus, msg: string | null = null) => { statusRef.current = s; setStatusState(s); setMessage(msg); };
  const commit = (next: Store) => { storeRef.current = next; setStoreState(next); };
  const writeCache = useCallback(() => {
    if (!storeRef.current) return;
    try { localStorage.setItem(cacheKey, JSON.stringify({ store: storeRef.current, revision: revisionRef.current, dirty: dirtyRef.current, savedAt: Date.now() } satisfies CacheShape)); setCacheError(null); }
    catch (e) {
      const quota = e instanceof DOMException && (e.name === 'QuotaExceededError' || e.code === 22);
      setCacheError(quota
        ? 'This device’s storage is full, so changes are not cached here. Anything not yet synced will be lost if you close this tab.'
        : 'This browser blocked local storage, so changes are not cached on this device. Anything not yet synced will be lost if you close this tab.');
    }
  }, [cacheKey]);
  const signal = () => { if (!controller.current || controller.current.signal.aborted) controller.current = new AbortController(); return controller.current.signal; };

  const applyRemote = (snap: Snapshot) => {
    revisionRef.current = snap.revision;
    setUpdatedAt(snap.updatedAt);
    commit(snap.state ? migrateStore(snap.state) : emptyStore());
    dirtyRef.current = false;
    writeCache();
  };

  const handleError = (e: unknown, phase: 'load' | 'save' | 'refresh') => {
    if ((e as Error)?.name === 'AbortError' || !alive.current) return;
    if (e instanceof ApiError && e.status === 401) { setStatus('auth', 'Your session ended. Sign in again to keep syncing; unsynced changes stay on this device.'); return; }
    if (e instanceof ApiError && e.status === 409) { conflictRef.current = true; setStatus('conflict', 'Your account changed on another device. Your local draft is kept and nothing was overwritten.'); return; }
    if (phase === 'refresh') return; // quiet background refresh failures
    if (e instanceof OfflineError) { setStatus(phase === 'load' ? 'load-error' : 'offline', 'You appear to be offline.'); return; }
    if (e instanceof ApiError && e.status === 400) { setStatus(phase === 'load' ? 'load-error' : 'error', 'The server rejected this save as invalid. Your changes are still on this device.'); return; }
    setStatus(phase === 'load' ? 'load-error' : 'error', e instanceof Error ? e.message : 'Something went wrong.');
  };

  const save = useCallback(async () => {
    window.clearTimeout(timer.current);
    if (!hydrated.current || inflight.current || conflictRef.current || !dirtyRef.current || !storeRef.current) return;
    if (statusRef.current === 'auth') return;
    inflight.current = true;
    setStatus('saving');
    const seq = editSeq.current;
    let retryAfter = false;
    try {
      const snap = await putState(storeRef.current, revisionRef.current, signal());
      if (!alive.current) return;
      revisionRef.current = snap.revision;
      setUpdatedAt(snap.updatedAt);
      if (editSeq.current === seq) { dirtyRef.current = false; setStatus('synced'); }
      else { setStatus('pending'); retryAfter = true; }
      writeCache();
    } catch (e) { handleError(e, 'save'); }
    finally {
      inflight.current = false;
      if (retryAfter && alive.current) timer.current = window.setTimeout(() => { void saveRef.current(); }, SAVE_DELAY);
    }
  }, [writeCache]); // eslint-disable-line react-hooks/exhaustive-deps
  const saveRef = useRef(save);
  saveRef.current = save;

  const hydrate = useCallback(async () => {
    setStatus('loading');
    try {
      const snap = await fetchState(signal());
      if (!alive.current) return;
      const cached = readCache(cacheKey);
      setUpdatedAt(snap.updatedAt);
      revisionRef.current = snap.revision;
      if (cached?.dirty) {
        commit(cached.store);
        dirtyRef.current = true;
        hydrated.current = true;
        if (cached.revision === snap.revision) { setStatus('pending'); void saveRef.current(); }
        else { conflictRef.current = true; setStatus('conflict', 'Unsynced changes on this device were made against an older version of your account.'); }
        return;
      }
      applyRemote(snap);
      hydrated.current = true;
      setStatus('synced');
    } catch (e) {
      // Offline after Clerk verified this same owner: show their device cache read-only. Writes stay paused until a server hydrate succeeds.
      if (e instanceof OfflineError && alive.current) {
        const cached = readCache(cacheKey);
        if (cached) { commit(cached.store); setStatus('offline', 'Offline: showing the copy cached on this device. Editing resumes once you reconnect.'); return; }
      }
      handleError(e, 'load');
    }
  }, [cacheKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = useCallback(async () => {
    if (!hydrated.current || conflictRef.current) return;
    if (dirtyRef.current) { if (statusRef.current === 'offline' || statusRef.current === 'pending') void saveRef.current(); return; }
    if (inflight.current) return;
    const seq = editSeq.current;
    try {
      const snap = await fetchState(signal());
      if (!alive.current || dirtyRef.current || inflight.current || editSeq.current !== seq || conflictRef.current) return;
      if (snap.revision !== revisionRef.current) applyRemote(snap);
      if (statusRef.current !== 'synced') setStatus('synced');
    } catch (e) { handleError(e, 'refresh'); }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const update = useCallback((patch: Partial<Store>): boolean => {
    const current = storeRef.current;
    if (!current || !hydrated.current) return false;
    commit({ ...current, ...patch });
    dirtyRef.current = true;
    editSeq.current += 1;
    writeCache();
    if (conflictRef.current || statusRef.current === 'auth') return true;
    if (statusRef.current !== 'saving') setStatus(navigator.onLine ? 'pending' : 'offline', navigator.onLine ? null : 'You appear to be offline.');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => { void saveRef.current(); }, SAVE_DELAY);
    return true;
  }, [writeCache]);

  const reloadRemote = useCallback(async () => {
    controller.current?.abort();
    window.clearTimeout(timer.current);
    setStatus('loading');
    try {
      const snap = await fetchState(signal());
      if (!alive.current) return;
      conflictRef.current = false;
      applyRemote(snap);
      hydrated.current = true;
      setStatus('synced');
    } catch (e) { handleError(e, 'load'); if (storeRef.current && statusRef.current === 'load-error') setStatus('error', 'Could not reload your account. Try again.'); }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const downloadDraft = useCallback(() => {
    if (!storeRef.current) return;
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), baseRevision: revisionRef.current, state: storeRef.current }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `habit-fuel-draft-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);
  }, []);

  const retry = useCallback(() => {
    if (!hydrated.current) { void hydrate(); return; }
    if (statusRef.current === 'auth') { void hydrate(); return; }
    void saveRef.current();
  }, [hydrate]);

  useEffect(() => {
    alive.current = true;
    void hydrate();
    const onWake = () => { if (document.visibilityState === 'visible') void refresh(); };
    const onOnline = () => { if (!hydrated.current) void hydrate(); else if (dirtyRef.current && !conflictRef.current) void saveRef.current(); else void refresh(); };
    const onOffline = () => { if (dirtyRef.current && !conflictRef.current) setStatus('offline', 'You appear to be offline.'); };
    const interval = window.setInterval(() => { if (document.visibilityState === 'visible') void refresh(); }, REFRESH_MS);
    window.addEventListener('focus', onWake);
    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      alive.current = false;
      controller.current?.abort();
      window.clearTimeout(timer.current);
      window.clearInterval(interval);
      window.removeEventListener('focus', onWake);
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [hydrate, refresh]);

  const hasUnsynced = () => dirtyRef.current;
  return { hasUnsynced, cacheError, store, status, message, updatedAt, update, retry, reloadRemote, downloadDraft };
}
