import { useEffect, useState } from 'react';
import { getLocalDateKey } from '@/lib/store';

/** Local calendar day key that rolls over at midnight and re-checks on focus / visibility resume. */
export function useTodayKey() {
  const [key, setKey] = useState(() => getLocalDateKey());
  useEffect(() => {
    let timer = 0;
    const refresh = () => {
      window.clearTimeout(timer);
      const now = new Date();
      setKey(getLocalDateKey(now));
      const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      timer = window.setTimeout(refresh, Math.max(1000, next.getTime() - now.getTime() + 200));
    };
    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    refresh();
    window.addEventListener('focus', refresh);
    window.addEventListener('pageshow', refresh);
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('focus', refresh);
      window.removeEventListener('pageshow', refresh);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, []);
  return key;
}
