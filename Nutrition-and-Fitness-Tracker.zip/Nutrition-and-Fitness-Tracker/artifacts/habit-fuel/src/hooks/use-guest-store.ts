import { useCallback, useRef, useState } from 'react';
import { emptyStore, migrateStore, STORAGE_KEY, type Store } from '@/lib/store';

/** Guest mode: the browser's original habit-fuel-v1 key. No API, no account cache. */
function readGuest(): { store: Store; error: string | null; unreadable: boolean } {
  let raw: string | null;
  try { raw = localStorage.getItem(STORAGE_KEY); }
  catch { return { store: emptyStore(), error: 'This browser blocked local storage. Guest changes will be lost when you close this tab.', unreadable: false }; }
  if (!raw) return { store: emptyStore(), error: null, unreadable: false };
  try { return { store: migrateStore(JSON.parse(raw)), error: null, unreadable: false }; }
  catch { return { store: emptyStore(), error: 'Saved guest data on this device could not be read. It has not been overwritten; making a change here will replace it.', unreadable: true }; }
}

function writeGuest(store: Store): string | null {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(store)); return null; }
  catch (e) {
    const quota = e instanceof DOMException && (e.name === 'QuotaExceededError' || e.code === 22);
    return quota ? 'Device storage is full, so your latest change was not saved. Delete older entries and try again.' : 'Your latest change could not be saved on this device. It will be lost if you close this tab.';
  }
}

export function useGuestStore() {
  const [initial] = useState(readGuest);
  const [store, setStore] = useState<Store>(initial.store);
  const [error, setError] = useState<string | null>(initial.error);
  const storeRef = useRef(store);
  const edited = useRef(false);

  const update = useCallback((patch: Partial<Store>) => {
    const next = { ...storeRef.current, ...patch };
    edited.current = true;
    storeRef.current = next;
    setStore(next);
    setError(writeGuest(next));
    return true;
  }, []);
  const retry = useCallback(() => {
    if (initial.unreadable && !edited.current) {
      const reloaded = readGuest();
      if (!reloaded.unreadable) {
        storeRef.current = reloaded.store;
        setStore(reloaded.store);
      }
      setError(reloaded.error);
      return;
    }
    setError(writeGuest(storeRef.current));
  }, [initial.unreadable]);
  return { store, error, update, retry };
}
