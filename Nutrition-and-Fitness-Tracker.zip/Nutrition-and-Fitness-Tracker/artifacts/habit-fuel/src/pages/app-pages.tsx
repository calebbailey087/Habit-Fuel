import { useMemo, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { Activity, Apple, ArrowRight, Check, CheckCircle2, ChevronRight, CircleHelp, Dumbbell, Edit3, Flame, Leaf, Plus, Salad, Trash2, Utensils } from 'lucide-react';
import { Empty, Field, Modal, PageHead } from '@/components/hf-ui';
import { foodTotals, money, newId as id, type PlanItem, type Shared } from '@/lib/store';

export const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export const dayLong: Record<string, string> = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

export function Dashboard({ store, todayKey }: Shared) {
  const foods = store.foods.filter(f => f.dateKey === todayKey);
  const totals = foodTotals(foods);
  const consumed = totals.calories;
  const goal = store.targets.calories;
  const workouts = store.workouts.filter(w => w.dateKey === todayKey);
  const loggedBurn = workouts.reduce((sum, w) => sum + w.caloriesBurnedEstimate, 0);
  const nextPlan = store.plan.find(p => !p.completed);
  return <div className="content">
    <PageHead eyebrow="Your daily check-in" title={greeting(store.profile.displayName)} copy="A little awareness goes a long way. Here's where today is at." action={<Link className="btn btn-primary" href="/log"><Plus size={16} /> Add to today</Link>} />
    <div className="hero-card">
      <div className="eyebrow">One day at a time</div>
      <h2>{consumed < goal ? 'You’re building a day that works for you.' : 'You showed up for yourself today.'}</h2>
      <p>Small, repeatable choices matter more than getting every number just right. Use your log as a guide, not a grade.</p>
      <div className="hero-actions"><Link href="/log" className="btn btn-primary"><Utensils size={15} /> Log a meal</Link><Link href="/plans" className="btn btn-secondary"><Dumbbell size={15} /> See your plan</Link></div>
    </div>
    <div className="grid dashboard-grid">
      <div className="grid">
        <section className="card">
          <div className="card-head"><div><h2>Food so far</h2><p>Nutrition estimates from what you logged</p></div><Link href="/log" className="btn btn-quiet btn-sm">Full log <ChevronRight size={14} /></Link></div>
          <div className="calorie-display"><strong>{money(consumed)}</strong><span>of {money(goal)} kcal</span></div>
          <div className="metric-list">
            <MacroMetric name="Protein" value={totals.protein} goal={store.targets.protein} unit="g" className="protein" />
            <MacroMetric name="Carbs" value={totals.carbs} goal={store.targets.carbs} unit="g" className="carbs" />
            <MacroMetric name="Fat" value={totals.fat} goal={store.targets.fat} unit="g" className="fat" />
          </div>
        </section>
        <section className="card">
          <div className="card-head"><div><h2>Today's log</h2><p>A quick look at what you’ve tracked</p></div><span className="pill">{foods.length + workouts.length} entries</span></div>
          {foods.length + workouts.length ? <div className="day-list">
            {foods.slice(0, 3).map(f => <div className="day-entry" key={f.id}><span className="entry-icon"><Apple size={17} /></span><div><div className="entry-title">{f.name}</div><div className="entry-meta">{f.meal} · {f.time}</div></div><div className="entry-cal">{money(f.calories)} kcal</div></div>)}
            {workouts.slice(0, 2).map(w => <div className="day-entry" key={w.id}><span className="entry-icon"><Dumbbell size={17} /></span><div><div className="entry-title">{w.name}</div><div className="entry-meta">{w.durationMinutes} min · {w.effort} effort</div></div><div className="entry-cal">Workout</div></div>)}
          </div> : <Empty title="A fresh start" copy="Your food and movement entries will show here." button="Log something" href="/log" />}
        </section>
      </div>
      <div className="grid">
        <section className="card">
          <div className="card-head"><div><h2>Movement</h2><p>Kept separate from your food totals</p></div><span className="entry-icon"><Flame size={17} /></span></div>
          <div className="calorie-display"><strong>{money(loggedBurn)}</strong><span>kcal estimated burn</span></div>
          <div className="notice" style={{ margin: '12px 0 0' }}>Workout burn is a rough estimate. It isn't subtracted from your food or calorie target.</div>
          <Link href="/log" className="btn btn-quiet btn-sm" style={{ marginTop: 10 }}>Log movement <ArrowRight size={14} /></Link>
        </section>
        <section className="card">
          <div className="card-head"><div><h2>Next on your plan</h2><p>Your routine, at your pace</p></div></div>
          {nextPlan ? <><div className="day-entry" style={{ borderTop: 0, paddingTop: 0 }}><span className="entry-icon"><Dumbbell size={17} /></span><div><div className="entry-title">{nextPlan.name}</div><div className="entry-meta">{dayLong[nextPlan.day] ?? nextPlan.day} · {nextPlan.durationMinutes} min</div></div></div><Link className="btn btn-secondary btn-sm" href="/plans">View routine <ChevronRight size={14} /></Link></> : <Empty title="Your plan is clear" copy="Add a routine or take a well-earned rest." button="View plan" href="/plans" />}
        </section>
        <section className="card soft-card">
          <div className="card-head"><div><h2>Targets are yours</h2><p>Set a starting point that feels useful.</p></div><CircleHelp size={17} className="muted" /></div>
          <Link href="/profile" className="btn btn-secondary btn-sm">Adjust your setup <ArrowRight size={14} /></Link>
        </section>
      </div>
    </div>
  </div>;
}
function greeting(name: string) { const hour = new Date().getHours(); const g = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'; return name.trim() ? `${g}, ${name.trim().split(' ')[0]}.` : `${g}.`; }
function MacroMetric({ name, value, goal, unit, className }: { name: string; value: number; goal: number; unit: string; className: string }) {
  const percent = Math.min(100, (value / Math.max(1, goal)) * 100);
  return <div className="metric" data-testid={`metric-${name.toLowerCase()}`}><div className="metric-name"><b>{name}</b>{money(value)} / {money(goal)} {unit}</div><div className="track"><div className={`fill ${className}`} style={{ width: `${percent}%` }} /></div><div className="metric-val">{Math.round(percent)}%</div></div>;
}
export function PlansPage({ store, update, notify }: Shared) {
  const [editing, setEditing] = useState<PlanItem | null>(null);
  const [newItem, setNewItem] = useState(false);
  const days = store.profile.daysAvailable;
  const sortedPlan = useMemo(() => [...store.plan].sort((a, b) => dayNames.indexOf(a.day) - dayNames.indexOf(b.day)), [store.plan]);
  const toggleComplete = (item: PlanItem) => { update({ plan: store.plan.map(p => p.id === item.id ? { ...p, completed: !p.completed } : p) }); notify(item.completed ? 'Workout marked as planned.' : 'Workout marked complete. Nice follow-through.'); };
  const save = (item: PlanItem) => { update({ plan: editing ? store.plan.map(p => p.id === editing.id ? item : p) : [...store.plan, item], profile: { ...store.profile, daysAvailable: days.includes(item.day) ? days : [...days, item.day] } }); notify(editing ? 'Plan updated.' : 'Workout added to your plan.'); setEditing(null); setNewItem(false); };
  const deleteItem = (item: PlanItem) => { if (!window.confirm(`Remove ${item.name} from your plan?`)) return; update({ plan: store.plan.filter(p => p.id !== item.id) }); notify('Plan item removed.'); };
  const updateDay = (item: PlanItem, day: string) => { update({ plan: store.plan.map(p => p.id === item.id ? { ...p, day } : p), profile: { ...store.profile, daysAvailable: days.includes(day) ? days : [...days, day] } }); };
  const toggleDay = (day: string) => { const selected = days.includes(day); const nextDays = selected ? days.filter(d => d !== day) : [...days, day]; update({ profile: { ...store.profile, daysAvailable: nextDays }, plan: selected ? store.plan.filter(p => p.day !== day) : store.plan }); };
  return <div className="content">
    <PageHead eyebrow="A routine that fits real life" title="Your plan" copy="Keep what already works, make small changes, and count a completed session as a win." action={<button className="btn btn-primary" onClick={() => setNewItem(true)}><Plus size={16} /> Add a session</button>} />
    <div className="grid two-col">
      <section className="card"><div className="card-head"><div><h2>Weekly rhythm</h2><p>Change a day here or adjust the days you have available.</p></div><span className="pill">{store.plan.filter(p => p.completed).length} complete</span></div>
        {sortedPlan.length ? sortedPlan.map(item => <div className="plan-item" key={item.id}><div><div className="plan-day">{dayLong[item.day] ?? item.day}</div><select aria-label={`Change day for ${item.name}`} value={item.day} onChange={e => updateDay(item, e.target.value)} className="control plan-select">{dayNames.map(d => <option key={d} value={d}>{d}</option>)}</select></div><div><div className="entry-title">{item.name} {item.completed && <span className="pill">Done</span>}</div><div className="entry-meta">{item.durationMinutes} minutes · {store.profile.routineMode}</div><div className="entry-actions" style={{ margin: '6px 0 0' }}><button className="btn btn-quiet btn-sm" onClick={() => setEditing(item)}><Edit3 size={13} /> Edit</button><button className="btn btn-quiet btn-sm" onClick={() => deleteItem(item)}><Trash2 size={13} /> Remove</button></div></div><button className={`check ${item.completed ? 'done' : ''}`} aria-label={item.completed ? 'Mark as not completed' : 'Mark workout complete'} onClick={() => toggleComplete(item)}>{item.completed && <Check size={13} />}</button></div>) : <Empty title="Make room for a routine" copy="Start with one session that feels realistic for this week." />}
      </section>
      <div className="grid">
        <section className="card"><div className="card-head"><div><h2>Your available days</h2><p>Choose the days that tend to work for you.</p></div></div><div className="schedule">{dayNames.map(day => <button key={day} className={`day-chip ${days.includes(day) ? 'selected' : ''}`} onClick={() => toggleDay(day)}>{day}</button>)}</div><div className="notice" style={{ margin: '16px 0 0' }}>Removing an available day also removes sessions scheduled on that day. You choose when changes happen.</div></section>
        <section className="card tint-card"><div className="eyebrow">A kind of progress</div><h2 style={{ marginTop: 9 }}>Repeatable beats perfect.</h2><p className="subhead" style={{ fontSize: 12, margin: '9px 0 15px' }}>Your plan is a suggestion you shape. A missed session is information, not a reason to start over.</p><span className="pill"><CheckCircle2 size={13} /> Built around your week</span></section>
      </div>
    </div>
    {(editing || newItem) && <PlanDialog item={editing} days={dayNames} onClose={() => { setEditing(null); setNewItem(false); }} onSave={save} />}
  </div>;
}
function PlanDialog({ item, days, onClose, onSave }: { item: PlanItem | null; days: string[]; onClose: () => void; onSave: (item: PlanItem) => void }) {
  const [name, setName] = useState(item?.name ?? '');
  const [day, setDay] = useState(item?.day ?? 'Mon');
  const [duration, setDuration] = useState(String(item?.durationMinutes ?? 30));
  const submit = (e: FormEvent) => { e.preventDefault(); onSave({ id: item?.id ?? id(), name: name.trim(), day, durationMinutes: Number(duration) || 0, completed: item?.completed ?? false }); };
  return <Modal title={item ? 'Edit a session' : 'Add a session'} copy="Choose a name, day, and time commitment that fits." onClose={onClose}><form onSubmit={submit}><div className="form-grid"><div className="field full"><label>Session name</label><input className="control" required value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Beginner strength" /></div><div className="field"><label>Day</label><select className="control" value={day} onChange={e => setDay(e.target.value)}>{days.map(d => <option value={d} key={d}>{dayLong[d]}</option>)}</select></div><Field label="Duration (minutes)" type="number" min="5" value={duration} onChange={setDuration} /></div><div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button className="btn btn-primary">Save session</button></div></form></Modal>;
}

export function CoachPage({ store, todayKey }: Shared) {
  const todayFoods = store.foods.filter(f => f.dateKey === todayKey);
  const todayWorkouts = store.workouts.filter(w => w.dateKey === todayKey);
  const totals = foodTotals(todayFoods);
  const workoutCount = todayWorkouts.length;
  const entriesCount = todayFoods.length;
  const insights = [
    { icon: <Salad size={16} />, tag: 'From your food log', title: entriesCount ? `You’ve logged ${money(totals.calories)} kcal across ${entriesCount} ${entriesCount === 1 ? 'food entry' : 'food entries'}.` : 'Your food log is ready when you are.', text: entriesCount ? 'This is a snapshot of what you chose to record today, not a complete measure of your nutrition. Every number here is one you entered.' : 'A meal or snack is enough to get started. You can leave details blank and come back to them later.', basis: `Visible log: ${entriesCount} food ${entriesCount === 1 ? 'entry' : 'entries'} · totals are calculated from the values you entered.` },
    { icon: <Dumbbell size={16} />, tag: 'From your movement log', title: workoutCount ? `${workoutCount} movement ${workoutCount === 1 ? 'session' : 'sessions'} logged so far today.` : 'Movement does not have to look one particular way.', text: workoutCount ? `Your workout burn estimate is ${money(todayWorkouts.reduce((n, w) => n + w.caloriesBurnedEstimate, 0))} kcal. That number can vary a lot in real life, so we keep it separate from food.` : 'A walk, a stretch, a sport, or a strength session all count if they matter to you.', basis: `Visible log: ${workoutCount} workout ${workoutCount === 1 ? 'entry' : 'entries'} · estimates use the values you supplied.` },
    { icon: <Leaf size={16} />, tag: 'A gentle nudge', title: totals.protein > 0 ? 'Your log is information you can learn from.' : 'Try noticing what helps your energy feel steady.', text: 'Look for patterns that make sense in your own week. One day rarely tells the whole story, and there is no need to chase a perfect number.', basis: `Based on today’s visible entries and your personal targets. We don’t infer recovery, readiness, or health conditions.` },
  ];
  return <div className="content"><PageHead eyebrow="A thoughtful check-in" title="Coach notes" copy="A few grounded observations from your own log. Ask when you’re curious; nothing here is a diagnosis." />
    <div className="grid two-col" style={{ alignItems: 'start' }}><section>
      {insights.map((item, i) => <article className="insight" key={i}><span className="pill">{item.icon}{item.tag}</span><h3>{item.title}</h3><p>{item.text}</p><div className="insight-basis"><b>Why this showed up:</b> {item.basis}</div></article>)}
    </section><aside className="card"><div className="eyebrow">Clear boundaries</div><h2 style={{ marginTop: 10 }}>Useful, not medical.</h2><p className="subhead" style={{ fontSize: 12, marginTop: 10 }}>These notes describe visible entries and user-set targets only. They are not medical advice or a diagnosis. Habit Fuel does not read wearable recovery or readiness data.</p><div className="notice" style={{ marginTop: 17 }}>Nutrition and activity numbers can be imprecise. For personal medical guidance, talk with a qualified health professional.</div></aside></div>
  </div>;
}
export function NotFound() {
  return <div className="content"><div className="empty" style={{ marginTop: 70 }}><Leaf size={24} /><strong>We couldn’t find that page.</strong><p>Head back to today and pick up where you left off.</p><Link className="btn btn-primary btn-sm" href="/today">Go to today</Link></div></div>;
}
