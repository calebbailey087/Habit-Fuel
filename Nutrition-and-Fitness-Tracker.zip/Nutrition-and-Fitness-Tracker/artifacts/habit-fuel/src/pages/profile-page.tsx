import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link } from 'wouter';
import { ArrowRight, Check, Leaf } from 'lucide-react';
import { Field, PageHead } from '@/components/hf-ui';
import { BodyAndEstimate, InstallCard, LegacyImportCard, StepsCard, ThemePicker } from '@/components/setup-extras';
import { recommendTargets } from '@/lib/calories';
import { mergeLegacy, readLegacyStore, type Profile, type Shared, type Targets } from '@/lib/store';
import { dayNames } from '@/pages/app-pages';

export type Identity = { initials: string; badge?: string; subtitle: string; actions: ReactNode };

export function ProfilePage({ store, update, notify, identity, dataNotice, allowLegacyImport }: Shared & { identity: Identity; dataNotice: ReactNode; allowLegacyImport: boolean }) {
  const [profile, setProfile] = useState(store.profile);
  const [targets, setTargets] = useState(store.targets);
  const [saved, setSaved] = useState(false);
  const formDirty = useRef(false);
  // Re-sync from the account only while the form has no unsaved edits.
  useEffect(() => { if (formDirty.current) return; setProfile(store.profile); setTargets(store.targets); }, [store.profile, store.targets]);
  const legacy = useMemo(() => (allowLegacyImport ? readLegacyStore() : null), [allowLegacyImport]);

  const edit = (fn: () => void) => { formDirty.current = true; fn(); };
  const patchProfile = (p: Partial<Profile>) => edit(() => setProfile(prev => ({ ...prev, ...p })));
  const setValue = (key: keyof Profile, value: string | number | string[]) => patchProfile({ [key]: value } as Partial<Profile>);
  const setTarget = (key: keyof Targets, v: string) => edit(() => setTargets(t => ({ ...t, [key]: Math.max(0, Math.round(Number(v) || 0)) })));
  const toggleEquipment = (value: string) => patchProfile({ equipment: profile.equipment.includes(value) ? profile.equipment.filter(x => x !== value) : [...profile.equipment, value] });
  const toggleDay = (value: string) => patchProfile({ daysAvailable: profile.daysAvailable.includes(value) ? profile.daysAvailable.filter(d => d !== value) : [...profile.daysAvailable, value] });

  const applyRecommendation = (next: Targets) => {
    setTargets(next);
    formDirty.current = false;
    update({ profile, targets: next });
    notify(`Applied ${next.calories.toLocaleString()} kcal · ${next.protein} g protein · ${next.carbs} g carbs · ${next.fat} g fat.`);
  };
  const save = (e: FormEvent) => {
    e.preventDefault();
    formDirty.current = false;
    update({ profile: { ...profile, displayName: profile.displayName.trim().slice(0, 100) }, targets });
    notify('Your setup has been saved.');
    setSaved(true); window.setTimeout(() => setSaved(false), 2500);
  };
  const rec = recommendTargets(profile);
  const matchesRec = rec.kind === 'ok' && rec.calories === targets.calories && rec.protein === targets.protein && rec.carbs === targets.carbs && rec.fat === targets.fat;

  return <div className="content">
    <PageHead eyebrow="Personal, practical, optional" title="Your setup" copy="Tell Habit Fuel what would make this useful for you. Body measurements are never needed to start logging." />
    <form onSubmit={save} className="profile-layout">
      <div className="grid">
        <section className="card" data-testid="card-account">
          <div className="card-head"><div><h2>You</h2><p>How Habit Fuel greets you, and your account.</p></div></div>
          <div className="account-row"><span className="avatar">{identity.initials}</span><div className="who"><b>{profile.displayName.trim() || 'No name yet'} {identity.badge && <span className="pill">{identity.badge}</span>}</b><span>{identity.subtitle}</span></div>
            <div className="row-gap">{identity.actions}</div></div>
          <div className="form-grid" style={{ marginTop: 16 }}><div className="field full"><label htmlFor="display-name">Display name</label><input id="display-name" className="control" maxLength={100} value={profile.displayName} onChange={e => setValue('displayName', e.target.value)} placeholder="What should we call you?" data-testid="input-display-name" /></div></div>
        </section>
        <ThemePicker value={store.theme} onChange={theme => { update({ theme }); notify(theme === 'dark' ? 'Evening theme on.' : theme === 'lavender' ? 'Lavender theme on.' : 'Garden theme on.'); }} />
        <section className="card"><div className="card-head"><div><h2>About your goals</h2><p>There is no wrong place to begin.</p></div></div><div className="form-grid">
          <div className="field"><label>What matters to you?</label><select className="control" value={profile.goal} onChange={e => setValue('goal', e.target.value)}>{['Build consistency', 'Feel stronger', 'More everyday energy', 'Support a nutrition goal', 'Explore what works'].map(x => <option key={x}>{x}</option>)}</select></div>
          <div className="field"><label>Fitness experience</label><select className="control" value={profile.experience} onChange={e => setValue('experience', e.target.value)}>{['New to exercise', 'Some experience', 'Experienced', 'Returning after a break'].map(x => <option key={x}>{x}</option>)}</select></div>
          <div className="field full"><label>How should your routine work?</label><select className="control" value={profile.routineMode} onChange={e => setValue('routineMode', e.target.value)}>{['Track my existing routine', 'Adapt my routine', 'Use a beginner plan'].map(x => <option key={x}>{x}</option>)}</select></div>
          <div className="field full"><label>Available days</label><div className="schedule">{dayNames.map(day => <button type="button" key={day} className={`day-chip ${profile.daysAvailable.includes(day) ? 'selected' : ''}`} onClick={() => toggleDay(day)}>{day}</button>)}</div></div>
          <Field label="Time available (minutes)" type="number" min="5" value={profile.minutesAvailable} onChange={value => setValue('minutesAvailable', Number(value))} />
          <div className="field"><label>Equipment you can use</label><div className="selection-row">{['Bodyweight', 'Dumbbells', 'Resistance bands', 'Gym', 'None'].map(e => <button type="button" key={e} className={`choice ${profile.equipment.includes(e) ? 'selected' : ''}`} onClick={() => toggleEquipment(e)}>{e}</button>)}</div></div>
          <div className="field full"><label>Movement limitations (optional)</label><textarea className="control" value={profile.movementNotes} onChange={e => setValue('movementNotes', e.target.value)} placeholder="Share anything you'd like your plan to account for, or leave blank." /></div>
          <div className="field full"><label>Nutrition preference</label><select className="control" value={profile.nutritionPreference} onChange={e => setValue('nutritionPreference', e.target.value)}>{['No preference', 'Vegetarian', 'Vegan', 'Pescatarian', 'Other / personal preference'].map(x => <option key={x}>{x}</option>)}</select></div>
        </div></section>
        <BodyAndEstimate profile={profile} setProfile={patchProfile} targets={targets} onApply={applyRecommendation} />
        <section className="card"><div className="card-head"><div><h2>Your nutrition targets</h2><p>Type your own numbers, or leave a target at zero to skip it.</p></div><span className="pill">{matchesRec ? 'Recommended' : 'Custom'}</span></div><div className="form-grid">
          <Field label="Calories (kcal)" type="number" min="0" inputMode="numeric" value={targets.calories} onChange={v => setTarget('calories', v)} testId="input-target-calories" />
          <Field label="Protein (g)" type="number" min="0" inputMode="numeric" value={targets.protein} onChange={v => setTarget('protein', v)} testId="input-target-protein" />
          <Field label="Carbohydrates (g)" type="number" min="0" inputMode="numeric" value={targets.carbs} onChange={v => setTarget('carbs', v)} testId="input-target-carbs" />
          <Field label="Fat (g)" type="number" min="0" inputMode="numeric" value={targets.fat} onChange={v => setTarget('fat', v)} testId="input-target-fat" />
        </div><div className="notice" style={{ marginTop: 16, marginBottom: 0 }}>Manual targets save exactly as typed and stay put, even if your metrics change. A recommendation only replaces them when you press Apply.</div></section>
        <button className="btn btn-primary save-setup" data-testid="button-save-setup"><Check size={16} /> {saved ? 'Saved' : 'Save your setup'}</button>
        {legacy && !store.legacyImported && <LegacyImportCard legacy={legacy} onImport={() => { const r = mergeLegacy(store, legacy); update(r.store); notify(r.added ? `Imported ${r.added} item${r.added === 1 ? '' : 's'}. Duplicates were skipped.` : 'Nothing new to import; everything was already here.'); }} />}
        {dataNotice}
        <StepsCard />
        <InstallCard />
      </div>
      <aside className="profile-aside"><Leaf size={22} /><h3>Your pace is the right pace.</h3><p>{allowLegacyImport ? 'Your setup syncs privately to your account.' : 'Your setup is saved on this device only.'} Change it whenever life changes; nothing here is a test.</p><Link className="btn btn-secondary btn-sm" href="/plans">View your plan <ArrowRight size={14} /></Link></aside>
    </form>
  </div>;
}
