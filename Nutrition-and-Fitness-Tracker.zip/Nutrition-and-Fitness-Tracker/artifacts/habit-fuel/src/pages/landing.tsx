import { Link } from 'wouter';
import { ArrowRight, Cloud, Dumbbell, Leaf, ShieldCheck } from 'lucide-react';

const base = import.meta.env.BASE_URL.replace(/\/$/, '');

export function Landing() {
  return <div className="landing">
    <header className="l-nav">
      <Link href="/" className="l-brand"><img src={`${base}/logo.svg`} alt="" />habit fuel</Link>
      <div className="l-nav-actions">
        <Link href="/guest" className="btn btn-quiet" data-testid="link-nav-guest">Use as guest</Link>
        <Link href="/sign-in" className="btn btn-quiet" data-testid="link-sign-in">Sign in</Link>
        <Link href="/sign-up" className="btn btn-primary" data-testid="link-sign-up">Start free</Link>
      </div>
    </header>

    <section className="l-hero">
      <div>
        <div className="eyebrow reveal">Food, movement, and a plan that bends</div>
        <h1 className="reveal d1">Steady looks <em>good</em> on you.</h1>
        <p className="lede reveal d2">Habit Fuel is a quiet log for meals and workouts, with targets you can actually explain. No streak guilt, no guessed calories from photos, no pretending a number is a verdict.</p>
        <div className="l-cta reveal d3">
          <Link href="/sign-up" className="btn btn-primary">Create your account <ArrowRight size={16} /></Link>
          <Link href="/sign-in" className="btn btn-secondary">I already have one</Link>
        </div>
        <p className="guest-cta reveal d3">Not ready for an account? <Link href="/guest" data-testid="link-landing-guest">Try it as a guest</Link>; everything stays on this device.</p>
      </div>
      <div className="l-figure reveal d2">
        <img src={`${base}/landing-hero.jpg`} alt="Breakfast bowl, a notebook with a handwritten habit list, and running shoes on linen" />
        <div className="l-float"><small>Protein today</small><strong>86 / 124 g</strong><div className="track"><div className="fill protein" style={{ width: '69%' }} /></div></div>
      </div>
    </section>

    <div className="l-band"><span>log a meal in seconds</span><span>·</span><span>several exercises per session</span><span>·</span><span>quick meals you repeat</span><span>·</span><span>a week that fits</span></div>

    <section className="l-section">
      <div className="eyebrow">How it works</div>
      <h2>Three small habits. That’s the whole method.</h2>
      <div className="l-steps">
        <div className="l-step"><div className="num">01</div><h3>Write down what you ate</h3><p>Type it, or tap a saved quick meal. Snap a label for reference while you enter the values yourself; nothing is estimated behind your back.</p></div>
        <div className="l-step"><div className="num">02</div><h3>Note how you moved</h3><p>A walk, a lift, a class. Add sets and reps for each exercise. Burn estimates stay separate from food.</p></div>
        <div className="l-step"><div className="num">03</div><h3>Look back kindly</h3><p>History by day, a plan you reshuffle, and coach notes that only describe what you logged.</p></div>
      </div>
    </section>

    <section className="l-section l-split">
      <div>
        <div className="eyebrow">Targets with receipts</div>
        <h2>Numbers you can trace back to you.</h2>
        <p className="lede">Add your age, height, weight, activity, and direction. Habit Fuel previews calories and macros and shows every step of the math: protein per kilogram, fat at 30%, carbs fill the rest. Nothing changes until you press Apply, and your own numbers always stay editable.</p>
        <p className="fine-print">Adults only. Starting points from general formulas, not medical advice.</p>
      </div>
      <div className="l-macro-demo">
        <div className="eyebrow">Preview · maintain · lightly active</div>
        <div className="calorie-display"><strong>2,340</strong><span>kcal / day</span></div>
        <div className="row"><span>Protein · 1.6 g/kg</span><b>117 g</b></div>
        <div className="row"><span>Fat · 30%</span><b>78 g</b></div>
        <div className="row"><span>Carbs · remainder</span><b>291 g</b></div>
        <span className="pill"><Leaf size={12} /> Applied only when you say so</span>
      </div>
    </section>

    <div className="l-dark">
      <section className="l-section">
        <div className="eyebrow" style={{ color: 'var(--highlight)' }}>Straight answers</div>
        <h2>What we do, and what we won’t pretend to.</h2>
        <div className="l-truths">
          <div><Cloud size={20} /><h3>Private, synced account</h3><p>Your log follows you when you sign in on another device. A cached copy keeps things quick on this one.</p></div>
          <div><ShieldCheck size={20} /><h3>No photo guessing</h3><p>Photos are references for you. We never claim to read calories from a picture.</p></div>
          <div><Dumbbell size={20} /><h3>No fake step counts</h3><p>Browsers can’t read your pedometer, so the web app doesn’t invent one. Log walks as movement.</p></div>
          <div><Leaf size={20} /><h3>Not a clinic</h3><p>Coach notes describe your entries. For medical guidance, talk to a qualified professional.</p></div>
        </div>
      </section>
    </div>

    <section className="l-section">
      <div className="eyebrow">Make it yours</div>
      <h2>Three moods. Switch any time.</h2>
      <div className="l-themes">
        <div className="l-theme t-classic"><span>Default</span><b>Garden</b><span>Sage, cream, a little brass.</span></div>
        <div className="l-theme t-dark"><span>For late check-ins</span><b>Evening</b><span>Deep forest, easy on the eyes.</span></div>
        <div className="l-theme t-lavender"><span>Softer</span><b>Lavender</b><span>Lilac and oat milk.</span></div>
      </div>
    </section>

    <section className="l-final">
      <h2 className="l-section" style={{ padding: 0, fontFamily: 'var(--app-font-display)', fontWeight: 400, fontSize: 'clamp(34px,5vw,62px)', letterSpacing: '-.03em', lineHeight: 1.05, maxWidth: 760, margin: '0 auto' }}>There is no perfect day. Just the next good choice.</h2>
      <div className="l-cta"><Link href="/sign-up" className="btn btn-primary">Start your log <ArrowRight size={16} /></Link><Link href="/guest" className="btn btn-secondary">Continue as guest</Link></div>
    </section>

    <footer className="l-foot"><span>habit fuel · a calm food and movement log</span><span>Not medical advice. Adults 18+ for targets.</span></footer>
  </div>;
}
