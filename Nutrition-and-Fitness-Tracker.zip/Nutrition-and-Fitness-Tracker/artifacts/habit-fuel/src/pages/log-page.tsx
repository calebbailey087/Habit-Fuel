import { useEffect, useMemo, useRef, useState } from 'react';
import { Apple, Bookmark, BookmarkCheck, ChevronLeft, ChevronRight, Dumbbell, Edit3, ImagePlus, Plus, Trash2 } from 'lucide-react';
import { Empty, PageHead } from '@/components/hf-ui';
import { FoodDialog, WorkoutDialog, type FoodMode } from '@/components/log-dialogs';
import { MealPresets, presetMatches } from '@/components/meal-presets';
import { foodTotals, formatKey, money, newId, shiftKey, timeLabel, type FoodEntry, type MealPreset, type Shared, type WorkoutEntry } from '@/lib/store';

const sourceTag = (s: string) => s === 'meal-photo' ? 'Old photo placeholder, please check' : s === 'label-photo' ? 'From label photo' : s === 'meal-photo-user' ? 'Meal photo, your values' : '';

export function LogPage({ store, update, notify, todayKey }: Shared) {
  const [tab, setTab] = useState<'food' | 'workout'>('food');
  const [dayKey, setDayKey] = useState(todayKey);
  const prevToday = useRef(todayKey);
  useEffect(() => { if (dayKey === prevToday.current) setDayKey(todayKey); prevToday.current = todayKey; }, [todayKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const [dialog, setDialog] = useState<'food' | 'workout' | 'preset' | null>(null);
  const [editingFood, setEditingFood] = useState<FoodEntry | null>(null);
  const [editingWorkout, setEditingWorkout] = useState<WorkoutEntry | null>(null);
  const [editingPreset, setEditingPreset] = useState<MealPreset | null>(null);
  const [foodMode, setFoodMode] = useState<FoodMode>('manual');
  const isToday = dayKey === todayKey;
  const foods = useMemo(() => store.foods.filter(f => f.dateKey === dayKey), [store.foods, dayKey]);
  const workouts = useMemo(() => store.workouts.filter(w => w.dateKey === dayKey), [store.workouts, dayKey]);
  const historyDays = useMemo(() => {
    const counts = new Map<string, number>();
    [...store.foods, ...store.workouts].forEach(e => { if (e.dateKey !== todayKey) counts.set(e.dateKey, (counts.get(e.dateKey) ?? 0) + 1); });
    return [...counts.entries()].sort((a, b) => b[0].localeCompare(a[0])).slice(0, 14);
  }, [store.foods, store.workouts, todayKey]);
  const totals = foodTotals(foods);
  const close = () => { setDialog(null); setEditingFood(null); setEditingWorkout(null); setEditingPreset(null); };
  const openFood = (mode: FoodMode = 'manual', item?: FoodEntry) => { setFoodMode(mode); setEditingFood(item ?? null); setDialog('food'); };
  const removeFood = (item: FoodEntry) => { if (!window.confirm(`Delete "${item.name}" from your food log?`)) return; update({ foods: store.foods.filter(f => f.id !== item.id) }); notify('Food entry removed.'); };
  const removeWorkout = (item: WorkoutEntry) => { if (!window.confirm(`Delete "${item.name}" from your movement log?`)) return; update({ workouts: store.workouts.filter(w => w.id !== item.id) }); notify('Workout removed.'); };
  const savePreset = (f: FoodEntry) => {
    if (store.presets.some(p => presetMatches(p, f))) { notify('Already saved as a quick meal.'); return; }
    update({ presets: [{ id: newId(), name: f.name, meal: f.meal, calories: f.calories, protein: f.protein, carbs: f.carbs, fat: f.fat, notes: f.notes }, ...store.presets] });
    notify('Saved as a quick meal.');
  };
  const quickAdd = (p: MealPreset) => {
    update({ foods: [{ id: newId(), dateKey: todayKey, time: timeLabel(), name: p.name, meal: p.meal, calories: p.calories, protein: p.protein, carbs: p.carbs, fat: p.fat, notes: p.notes, estimateSource: 'preset' }, ...store.foods] });
    if (!isToday) setDayKey(todayKey);
    notify(`${p.name} added to today.`);
  };
  const deletePreset = (p: MealPreset) => { if (!window.confirm(`Delete the quick meal "${p.name}"? Logged entries stay.`)) return; update({ presets: store.presets.filter(x => x.id !== p.id) }); notify('Quick meal deleted.'); };
  const dayTitle = isToday ? 'Today' : dayKey === shiftKey(todayKey, -1) ? 'Yesterday' : formatKey(dayKey);

  return <div className="content">
    <PageHead eyebrow="Your notes, not a scorecard" title="Food & movement" copy="Each day starts fresh at local midnight. Earlier days stay here to browse, edit, or tidy up." action={<button className="btn btn-primary" onClick={() => tab === 'food' ? openFood() : setDialog('workout')} data-testid="button-add-log"><Plus size={16} /> Add {tab === 'food' ? 'food' : 'workout'}{isToday ? '' : ` to ${formatKey(dayKey, { month: 'short', day: 'numeric' })}`}</button>} />
    <div className="date-nav" data-testid="nav-log-date">
      <button className="icon-button" aria-label="Previous day" onClick={() => setDayKey(k => shiftKey(k, -1))} data-testid="button-prev-day"><ChevronLeft size={18} /></button>
      <div className="date-nav-label"><strong data-testid="text-log-day">{dayTitle}</strong><span>{formatKey(dayKey, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span></div>
      <input type="date" className="control date-input" value={dayKey} max={todayKey} onChange={e => e.target.value && setDayKey(e.target.value)} aria-label="Pick a day" data-testid="input-log-date" />
      <button className="icon-button" aria-label="Next day" disabled={isToday} onClick={() => setDayKey(k => shiftKey(k, 1))} data-testid="button-next-day"><ChevronRight size={18} /></button>
      {!isToday && <button className="btn btn-secondary btn-sm" onClick={() => setDayKey(todayKey)} data-testid="button-jump-today">Today</button>}
    </div>
    <div className="overview-row">
      <div className="stat-box"><small>Food calories</small><strong data-testid="text-day-calories">{money(totals.calories)}</strong><span>kcal</span></div>
      <div className="stat-box"><small>Protein · carbs · fat</small><strong>{money(totals.protein)} / {money(totals.carbs)} / {money(totals.fat)}</strong><span>g</span></div>
      <div className="stat-box"><small>Workout burn estimate</small><strong>{money(workouts.reduce((a, w) => a + w.caloriesBurnedEstimate, 0))}</strong><span>kcal, separate</span></div>
    </div>
    <div className="log-layout">
      <section className="card">
        <div className="card-head log-head"><div><h2>{isToday ? 'Your entries' : `Entries for ${dayTitle}`}</h2><p>Update or remove entries whenever you like.</p></div><div className="tabs"><button className={`tab ${tab === 'food' ? 'active' : ''}`} onClick={() => setTab('food')} data-testid="tab-food">Food ({foods.length})</button><button className={`tab ${tab === 'workout' ? 'active' : ''}`} onClick={() => setTab('workout')} data-testid="tab-workout">Movement ({workouts.length})</button></div></div>
        {tab === 'food' ? <>
          <div className="quick-buttons">
            <button className="btn btn-secondary btn-sm" onClick={() => openFood()} data-testid="button-food-manual"><Plus size={14} /> Manual entry</button>
            <button className="btn btn-secondary btn-sm" onClick={() => openFood('label-photo')} data-testid="button-food-label"><ImagePlus size={14} /> Label photo</button>
            <button className="btn btn-secondary btn-sm" onClick={() => openFood('meal-photo')} data-testid="button-food-meal-photo"><ImagePlus size={14} /> Meal photo</button>
          </div>
          {foods.length ? foods.map(f => { const saved = store.presets.some(p => presetMatches(p, f)); const tag = sourceTag(f.estimateSource); return <div className="log-row" key={f.id} data-testid={`row-food-${f.id}`}><div className="row-main"><span className="entry-icon"><Apple size={17} /></span><div className="row-copy"><div className="row-title">{f.name} {tag && <span className="pill">{tag}</span>}</div><div className="row-detail">{f.meal} · {f.time} · P {f.protein}g · C {f.carbs}g · F {f.fat}g{f.notes ? ` · ${f.notes}` : ''}</div></div></div><div className="row-side"><b className="row-kcal">{money(f.calories)} kcal</b><div className="entry-actions"><button className={`icon-button ${saved ? 'is-saved' : ''}`} aria-label={saved ? `${f.name} is a quick meal` : `Save ${f.name} as quick meal`} onClick={() => savePreset(f)} data-testid={`button-save-preset-${f.id}`}>{saved ? <BookmarkCheck size={15} /> : <Bookmark size={15} />}</button><button className="icon-button" aria-label={`Edit ${f.name}`} onClick={() => openFood('manual', f)} data-testid={`button-edit-food-${f.id}`}><Edit3 size={15} /></button><button className="icon-button" aria-label={`Delete ${f.name}`} onClick={() => removeFood(f)} data-testid={`button-delete-food-${f.id}`}><Trash2 size={15} /></button></div></div></div>; })
            : <Empty title={isToday ? 'Nothing logged yet today' : 'Nothing logged this day'} copy={isToday ? 'Start with a meal, a snack, or a quick meal from your saved list.' : 'That is fine. You can still add something you remember.'} />}
        </> : <>
          {workouts.length ? workouts.map(w => <div className="log-row" key={w.id} data-testid={`row-workout-${w.id}`}><div className="row-main"><span className="entry-icon"><Dumbbell size={17} /></span><div className="row-copy"><div className="row-title">{w.name}</div><div className="row-detail">{w.type} · {w.durationMinutes} min · {w.effort} effort</div>{w.exercises.length > 0 && <ul className="exercise-summary">{w.exercises.map((e, i) => <li key={i}><b>{e.name}</b> {e.sets || e.reps ? `${e.sets} × ${e.reps}` : ''}{e.weight ? ` @ ${e.weight} lb` : ''}</li>)}</ul>}</div></div><div className="row-side"><b className="row-kcal">~{w.caloriesBurnedEstimate} kcal</b><div className="entry-actions"><button className="icon-button" aria-label={`Edit ${w.name}`} onClick={() => { setEditingWorkout(w); setDialog('workout'); }} data-testid={`button-edit-workout-${w.id}`}><Edit3 size={15} /></button><button className="icon-button" aria-label={`Delete ${w.name}`} onClick={() => removeWorkout(w)} data-testid={`button-delete-workout-${w.id}`}><Trash2 size={15} /></button></div></div></div>)
            : <Empty title="Movement can look many ways" copy="Log a walk, a stretch break, strength work, or whatever you did." />}
          <div className="notice" style={{ marginTop: 14 }}>Estimated workout burn is shown separately and is not subtracted from food calories. Treat it as a rough reference.</div>
        </>}
      </section>
      <div className="grid">
        <MealPresets presets={store.presets} onAdd={quickAdd} onEdit={p => { setEditingPreset(p); setDialog('preset'); }} onDelete={deletePreset} />
        <section className="card" data-testid="card-history">
          <div className="card-head"><div><h2>Earlier days</h2><p>History stays until you delete it.</p></div></div>
          {historyDays.length ? <div className="history-list">{historyDays.map(([k, n]) => <button key={k} className={`history-day ${k === dayKey ? 'active' : ''}`} onClick={() => setDayKey(k)} data-testid={`button-history-${k}`}><span>{formatKey(k)}</span><small>{n} {n === 1 ? 'entry' : 'entries'}</small></button>)}</div> : <p className="presets-empty">After midnight, today's entries move here.</p>}
        </section>
      </div>
    </div>
    {dialog === 'food' && <FoodDialog key={`${editingFood?.id ?? 'new'}-${foodMode}`} item={editingFood} mode={foodMode} dateKey={dayKey} onClose={close} onSave={item => { update({ foods: editingFood ? store.foods.map(f => f.id === editingFood.id ? item : f) : [item, ...store.foods] }); notify(editingFood ? 'Food entry updated.' : 'Food added to your log.'); close(); }} />}
    {dialog === 'preset' && editingPreset && <FoodDialog key={editingPreset.id} item={null} preset={editingPreset} mode="manual" dateKey={todayKey} onClose={close} onSave={() => undefined} onSavePreset={p => { update({ presets: store.presets.map(x => x.id === p.id ? p : x) }); notify('Quick meal updated.'); close(); }} />}
    {dialog === 'workout' && <WorkoutDialog item={editingWorkout} dateKey={dayKey} onClose={close} onSave={item => { update({ workouts: editingWorkout ? store.workouts.map(w => w.id === editingWorkout.id ? item : w) : [item, ...store.workouts] }); notify(editingWorkout ? 'Workout updated.' : 'Movement added to your log.'); close(); }} />}
  </div>;
}
