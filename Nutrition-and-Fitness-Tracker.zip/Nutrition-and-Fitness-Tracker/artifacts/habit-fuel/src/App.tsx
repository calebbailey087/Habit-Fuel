import { useEffect, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, Show, useAuth, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { Link, Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { AlertTriangle, ArrowLeft, Download, LogOut, RefreshCw } from 'lucide-react';
import { useAccountStore, type SyncStatus } from '@/hooks/use-account-store';
import { AppShell } from '@/components/app-shell';
import { SyncNotice } from '@/components/setup-extras';
import { GuestApp } from '@/guest-app';
import { Landing } from '@/pages/landing';

// REQUIRED — copy verbatim.
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

// REQUIRED — copy verbatim. Empty in dev, auto-set in prod.
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const ink = '#24382d';
const clerkAppearance = {
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#285541',
    colorForeground: ink,
    colorMutedForeground: '#5f6e63',
    colorDanger: '#a24e3e',
    colorBackground: '#fdfbf6',
    colorInput: '#fffdf8',
    colorInputForeground: ink,
    colorNeutral: '#3c4a40',
    fontFamily: "'DM Sans', sans-serif",
    borderRadius: '0.7rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: { background: '#fdfbf6', borderRadius: '22px', width: 'min(440px, 100%)', maxWidth: '100%', minWidth: 0, overflow: 'hidden', border: '1px solid #e6e1d5', boxShadow: '0 24px 60px rgba(33,75,61,.10)' },
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: { color: ink, fontFamily: "'Fraunces', serif", fontWeight: 400, fontSize: '28px', letterSpacing: '-0.02em' },
    headerSubtitle: { color: '#5f6e63' },
    socialButtonsBlockButtonText: { color: ink, fontWeight: 600 },
    formFieldLabel: { color: '#3f5546', fontWeight: 600 },
    footerActionLink: { color: '#285541', fontWeight: 700 },
    footerActionText: { color: '#5f6e63' },
    dividerText: { color: '#6f7a6f' },
    identityPreviewEditButton: { color: '#285541' },
    formFieldSuccessText: { color: '#2f6b4b' },
    alertText: { color: '#8d4334' },
    logoBox: { height: '44px', justifyContent: 'center' },
    logoImage: { height: '44px', width: '44px' },
    socialButtonsBlockButton: { background: '#fffdf8', border: '1px solid #deded2' },
    formButtonPrimary: { background: '#285541', color: '#fffaf0', fontWeight: 700, minHeight: '44px', boxShadow: 'none' },
    formFieldInput: { background: '#fffdf8', color: ink, border: '1px solid #deded2', minHeight: '44px', fontSize: '16px' },
    footerAction: { background: 'transparent' },
    dividerLine: { background: '#e6e1d5' },
    alert: { background: '#f5e4df', border: '1px solid #ebcabf' },
    otpCodeFieldInput: { color: ink, border: '1px solid #deded2', fontSize: '16px' },
    formFieldRow: { marginBottom: '2px' },
    main: { gap: '18px' },
  },
};

function AuthFrame({ children, title, copy }: { children: ReactNode; title: string; copy: string }) {
  useEffect(() => { document.documentElement.dataset.theme = 'classic'; }, []);
  return <div className="auth-page" data-theme="classic">
    <aside className="auth-side">
      <Link href="/" className="l-brand"><img src={`${basePath}/logo.svg`} alt="" width={34} height={34} />habit fuel</Link>
      <div><h2>{title}</h2><p>{copy}</p></div>
      <p style={{ fontSize: 12 }}>Your log is private to your account. Signing in needs a connection.</p>
    </aside>
    <main className="auth-main"><div className="auth-stack"><div className="auth-top"><Link href="/" className="btn btn-quiet btn-sm"><ArrowLeft size={14} /> Back</Link><Link href="/guest" className="btn btn-secondary btn-sm" data-testid="link-auth-guest">Continue without an account</Link></div>{children}</div></main>
  </div>;
}

function SignInPage() {
  return <AuthFrame title="Pick up where you left off." copy="Your meals, workouts, quick meals and plan are waiting, synced from wherever you last logged.">
    <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
  </AuthFrame>;
}

function SignUpPage() {
  return <AuthFrame title="A calmer way to keep track." copy="Start with an empty log. No sample data, no streaks to protect. Just your own entries, synced to your account.">
    <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
  </AuthFrame>;
}

function HomeRedirect() {
  const { isLoaded } = useAuth();
  // Guest entry remains usable while an optional account session is loading.
  if (!isLoaded) return <Landing />;
  return <>
    <Show when="signed-in"><Redirect to="/today" /></Show>
    <Show when="signed-out"><Landing /></Show>
  </>;
}

function BootSkeleton() {
  return <div className="app-shell"><div className="boot"><div className="boot-card" style={{ width: 'min(100%, 680px)' }}>
    <div className="skeleton" style={{ width: 140, height: 14 }} /><div className="skeleton" style={{ width: '70%', height: 40 }} />
    <div className="skeleton" style={{ width: '100%', height: 150 }} /><div className="skeleton" style={{ width: '100%', height: 110 }} />
    <p>Loading your account…</p>
  </div></div></div>;
}

function PrivateApp() {
  const { isLoaded } = useAuth();
  if (!isLoaded) return <BootSkeleton />;
  return <>
    <Show when="signed-in"><AccountGate /></Show>
    <Show when="signed-out"><Redirect to="/" /></Show>
  </>;
}

function AccountGate() {
  const { user, isLoaded } = useUser();
  if (!isLoaded || !user) return <BootSkeleton />;
  const email = user.primaryEmailAddress?.emailAddress ?? '';
  // Remount on owner change so no state leaks between accounts.
  return <SyncedApp key={user.id} userId={user.id} email={email} fallbackName={user.firstName ?? ''} />;
}

const statusLabel: Record<SyncStatus, string> = { loading: 'Loading', 'load-error': 'Not loaded', synced: 'Synced', pending: 'Unsaved changes', saving: 'Syncing…', offline: 'Offline', error: 'Not synced', conflict: 'Sync conflict', auth: 'Sign in again' };

function SyncedApp({ userId, email, fallbackName }: { userId: string; email: string; fallbackName: string }) {
  const sync = useAccountStore(userId);
  const { signOut } = useClerk();

  const doSignOut = () => {
    if (sync.hasUnsynced() && !window.confirm('Some changes have not synced to your account yet. They may survive only in this device’s cache (if storage is available) and could be lost. Sign out anyway?')) return;
    void signOut({ redirectUrl: basePath || '/' });
  };

  if (!sync.store) {
    if (sync.status === 'loading') return <BootSkeleton />;
    return <div className="boot"><div className="boot-card card">
      <AlertTriangle size={24} className="muted" />
      <h2>We couldn’t load your account.</h2>
      <p>{sync.message ?? 'Something went wrong reaching Habit Fuel.'} Nothing has been changed.</p>
      <div className="row-gap"><button className="btn btn-primary" onClick={sync.retry} data-testid="button-retry-load"><RefreshCw size={15} /> Try again</button><button className="btn btn-secondary" onClick={doSignOut}>Sign out</button></div>
    </div></div>;
  }

  const showBanner = ['offline', 'error', 'conflict', 'auth'].includes(sync.status);
  const banners = <>
    {showBanner && <div className="storage-banner" role="alert" data-testid="status-sync-banner"><AlertTriangle size={16} />
      <div><b>{sync.status === 'conflict' ? 'Not overwritten.' : sync.status === 'auth' ? 'Signed out elsewhere.' : 'Not synced yet.'}</b> {sync.message}</div>
      <div className="actions">
        {sync.status === 'conflict' ? <>
          <button className="btn btn-secondary btn-sm" onClick={sync.downloadDraft} data-testid="button-download-draft"><Download size={13} /> Download my draft</button>
          <button className="btn btn-danger btn-sm" onClick={() => { if (window.confirm('Load the latest version from your account? Your local draft will be replaced (download it first to keep a copy).')) void sync.reloadRemote(); }} data-testid="button-reload-remote"><RefreshCw size={13} /> Load account version</button>
        </> : sync.status === 'auth' ? <button className="btn btn-secondary btn-sm" onClick={doSignOut}>Sign in again</button>
          : <button className="btn btn-secondary btn-sm" onClick={sync.retry} data-testid="button-retry-save"><RefreshCw size={13} /> Try again</button>}
      </div>
    </div>}
    {sync.cacheError && <div className="storage-banner" role="alert" data-testid="status-cache-error"><AlertTriangle size={16} /><div><b>Not cached on this device.</b> {sync.cacheError} {sync.status === 'synced' ? 'Your account copy is up to date.' : 'Stay on this page until the status says Synced.'}</div></div>}
  </>;

  return <AppShell
    store={sync.store}
    update={sync.update}
    name={sync.store.profile.displayName || fallbackName}
    allowLegacyImport
    statusChip={<span className={`sync-chip ${sync.status}`} role="status" aria-live="polite" data-testid="status-sync" title={sync.updatedAt ? `Last synced ${new Date(sync.updatedAt).toLocaleString()}` : undefined}><span className="dot" />{statusLabel[sync.status]}</span>}
    banners={banners}
    identity={{ subtitle: email, actions: <button type="button" className="btn btn-secondary btn-sm" onClick={doSignOut} data-testid="button-sign-out"><LogOut size={14} /> Sign out</button> }}
    dataNotice={<SyncNotice />}
  />;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to your Habit Fuel log' } },
        signUp: { start: { title: 'Start your log', subtitle: 'A private, synced home for meals and movement' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={PrivateApp} />
      </Switch>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <Switch>
        {/* Guest mode lives outside ClerkProvider: no auth loading, no API. */}
        <Route path="/guest" nest><GuestApp /></Route>
        <Route><ClerkProviderWithRoutes /></Route>
      </Switch>
    </WouterRouter>
  );
}

export default App;
