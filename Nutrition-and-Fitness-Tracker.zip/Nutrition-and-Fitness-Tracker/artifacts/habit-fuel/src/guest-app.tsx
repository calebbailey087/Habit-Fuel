import { Link, Redirect, Route, Switch } from 'wouter';
import { AlertTriangle, LogIn, LogOut, UserPlus } from 'lucide-react';
import { AppShell } from '@/components/app-shell';
import { GuestNotice } from '@/components/setup-extras';
import { useGuestStore } from '@/hooks/use-guest-store';

/** Guest mode. Mounted under a nested /guest base, outside ClerkProvider; no auth hooks, no API. */
export function GuestApp() {
  const guest = useGuestStore();
  return <Switch>
    <Route path="/"><Redirect to="/today" replace /></Route>
    <Route>
      <AppShell
        store={guest.store}
        update={guest.update}
        name={guest.store.profile.displayName}
        allowLegacyImport={false}
        statusChip={<span className={`sync-chip ${guest.error ? 'error' : 'synced'}`} data-testid="status-guest"><span className="dot" />{guest.error ? 'Not saved' : 'Guest · this device'}</span>}
        banners={guest.error && <div className="storage-banner" role="alert" data-testid="status-storage-error"><AlertTriangle size={16} /><div><b>Not saved.</b> {guest.error}</div><div className="actions"><button className="btn btn-secondary btn-sm" onClick={guest.retry} data-testid="button-retry-save">Try again</button></div></div>}
        identity={{
          badge: 'Guest',
          subtitle: 'Saved on this device only. No account, no sync.',
          actions: <>
            <Link href="~/sign-up" className="btn btn-primary btn-sm" data-testid="link-guest-sign-up"><UserPlus size={14} /> Create account</Link>
            <Link href="~/sign-in" className="btn btn-secondary btn-sm" data-testid="link-guest-sign-in"><LogIn size={14} /> Sign in</Link>
            <Link href="~/" className="btn btn-quiet btn-sm" data-testid="link-leave-guest"><LogOut size={14} /> Leave guest mode</Link>
          </>,
        }}
        dataNotice={<GuestNotice />}
      />
    </Route>
  </Switch>;
}
