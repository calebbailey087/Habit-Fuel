import { useEffect, useState } from 'react';

type OfflineStatus = 'ready' | 'update' | 'error';
const eventName = 'habit-fuel:offline-status';
let registration: ServiceWorkerRegistration | undefined;
let updateRequested = false;

function announce(status: OfflineStatus) {
  window.dispatchEvent(new CustomEvent(eventName, { detail: status }));
}

async function registerOfflineShell() {
  // Development must stay un-cached. Installation/offline are verified on the
  // production build, and become available on the published HTTPS URL.
  if (!import.meta.env.PROD || !('serviceWorker' in navigator)) return;
  try {
    if (!window.isSecureContext) throw new Error('Offline installation requires HTTPS.');
    const base = import.meta.env.BASE_URL;
    registration = await navigator.serviceWorker.register(`${base}sw.js`, {
      scope: base,
      updateViaCache: 'none',
    });
    if (registration.waiting) announce('update');
    registration.addEventListener('updatefound', () => {
      const installing = registration?.installing;
      installing?.addEventListener('statechange', () => {
        if (installing.state === 'installed') {
          announce(navigator.serviceWorker.controller ? 'update' : 'ready');
        }
      });
    });
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (updateRequested) window.location.reload();
    });
    // Covers an installation that completed before updatefound was attached.
    await navigator.serviceWorker.ready;
    if (!registration.waiting) announce('ready');
  } catch (error) {
    console.error('Habit Fuel offline setup failed:', error);
    announce('error');
  }
}

export function PwaStatus() {
  const [offline, setOffline] = useState(!navigator.onLine);
  const [status, setStatus] = useState<OfflineStatus | null>(null);
  useEffect(() => {
    const onOnline = () => setOffline(false);
    const onOffline = () => setOffline(true);
    const onStatus = (event: Event) => setStatus((event as CustomEvent<OfflineStatus>).detail);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    window.addEventListener(eventName, onStatus);
    void registerOfflineShell();
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
      window.removeEventListener(eventName, onStatus);
    };
  }, []);
  useEffect(() => {
    if (status !== 'ready') return;
    const timer = window.setTimeout(() => setStatus(null), 5000);
    return () => window.clearTimeout(timer);
  }, [status]);
  if (!offline && !status) return null;
  const message = offline
    ? 'You’re offline. Account sync is paused; check the sync status before relying on recent changes.'
    : status === 'update'
      ? 'A new version is ready. Save any open forms before updating.'
      : status === 'error'
        ? 'Offline setup is unavailable. You can keep using Habit Fuel online.'
        : 'The app shell is cached. Signing in and syncing still need a connection.';
  return (
    <aside
      role="status"
      aria-live="polite"
      data-testid="pwa-status"
      style={{
        position: 'fixed', zIndex: 150, bottom: 'calc(88px + env(safe-area-inset-bottom, 0px))',
        left: 'max(12px, env(safe-area-inset-left, 0px))', right: 'max(12px, env(safe-area-inset-right, 0px))',
        maxWidth: 510, marginInline: 'auto', padding: 16, borderRadius: 16,
        background: '#243831', color: '#fbf9f4', boxShadow: '0 6px 24px #0002',
        display: 'flex', alignItems: 'center', gap: 12, fontSize: 14,
      }}
    >
      <span style={{ flex: 1 }}>{message}</span>
      {status === 'update' && !offline ? (
        <button className="btn btn-secondary btn-sm" onClick={() => {
          if (!registration?.waiting) { setStatus(null); return; }
          if (!window.confirm('Update Habit Fuel now? Save any open forms first. Saved logs will be kept.')) return;
          updateRequested = true;
          registration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }}>Update</button>
      ) : null}
      {!offline ? <button aria-label="Dismiss offline status" onClick={() => setStatus(null)} style={{ color: 'inherit', background: 'none', border: 0, fontSize: 22, padding: 8 }}>×</button> : null}
    </aside>
  );
}
