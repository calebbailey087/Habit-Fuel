import { useState } from 'react';
import { AlertTriangle, Check, Cloud, Download, Footprints, HardDrive, Share, SquarePlus } from 'lucide-react';
import { activityOptions, MIN_APPLY, recommendTargets } from '@/lib/calories';
import type { CalorieEquation, Profile, Store, Targets, ThemeName, WeightGoal } from '@/lib/store';

const optNum = (v: string, decimal = false) => { if (!v.trim()) return null; const n = Number(v); if (!Number.isFinite(n) || n < 0) return null; return decimal ? n : Math.round(n); };
const equations: { value: CalorieEquation; label: string }[] = [{ value: 'range', label: 'Show a range' }, { value: 'female', label: 'Female equation' }, { value: 'male', label: 'Male equation' }];
const goals: { value: WeightGoal; label: string }[] = [{ value: 'lose', label: 'Lose ~1 lb / week' }, { value: 'maintain', label: 'Maintain' }, { value: 'gain', label: 'Gain ~1 lb / week' }];

export function BodyAndEstimate({ profile, setProfile, targets, onApply }: { profile: Profile; setProfile: (p: Partial<Profile>) => void; targets: Targets; onApply: (t: Targets) => void }) {
  const rec = recommendTargets(profile);
  const bad = (f: string) => rec.kind === 'invalid' && rec.issues.some(i => i.field === f);
  const applied = rec.kind === 'ok' && targets.calories === rec.calories && targets.protein === rec.protein && targets.carbs === rec.carbs && targets.fat === rec.fat;
  return <section className="card" data-testid="card-calorie-estimate">
    <div className="card-head"><div><h2>Recommended targets</h2><p>From your metrics. Only applied when you say so.</p></div><span className="pill">Adults 18+</span></div>
    <div className="form-grid body-grid">
      <div className="field"><label>Age (years)</label><input className={`control ${bad('age') ? 'invalid' : ''}`} type="number" inputMode="numeric" min="0" value={profile.ageYears ?? ''} onChange={e => setProfile({ ageYears: optNum(e.target.value) })} placeholder="e.g. 34" data-testid="input-profile-age" /></div>
      <div className="field"><label>Weight (lb)</label><input className={`control ${bad('weight') ? 'invalid' : ''}`} type="number" inputMode="decimal" min="0" step="0.1" value={profile.weightPounds ?? ''} onChange={e => setProfile({ weightPounds: optNum(e.target.value, true) })} placeholder="e.g. 165" data-testid="input-profile-weight" /></div>
      <div className="field"><label>Height (ft)</label><input className={`control ${bad('height') ? 'invalid' : ''}`} type="number" inputMode="numeric" min="0" max="8" value={profile.heightFeet ?? ''} onChange={e => setProfile({ heightFeet: optNum(e.target.value) })} placeholder="5" data-testid="input-profile-height-feet" /></div>
      <div className="field"><label>Height (in)</label><input className={`control ${bad('height') ? 'invalid' : ''}`} type="number" inputMode="numeric" min="0" max="11" value={profile.heightInches ?? ''} onChange={e => { const n = optNum(e.target.value); setProfile({ heightInches: n === null ? null : Math.min(11, n) }); }} placeholder="0-11" data-testid="input-profile-height-inches" /></div>
      <div className="field full"><label>Typical activity</label><div className="selection-row">{activityOptions.map(a => <button type="button" key={a.label} className={`choice ${profile.activityLevel === a.label ? 'selected' : ''}`} onClick={() => setProfile({ activityLevel: a.label })} data-testid={`button-activity-${a.label.toLowerCase().replace(/ /g, '-')}`}>{a.label}</button>)}</div></div>
      <div className="field full"><label>Direction</label><div className="selection-row">{goals.map(g => <button type="button" key={g.value} className={`choice ${profile.weightGoal === g.value ? 'selected' : ''}`} onClick={() => setProfile({ weightGoal: g.value })} data-testid={`button-weight-goal-${g.value}`}>{g.label}</button>)}</div></div>
      <div className="field full"><label>Equation</label><div className="selection-row">{equations.map(q => <button type="button" key={q.value} className={`choice ${profile.calorieEquation === q.value ? 'selected' : ''}`} onClick={() => setProfile({ calorieEquation: q.value })} data-testid={`button-equation-${q.value}`}>{q.label}</button>)}</div></div>
    </div>
    {rec.kind === 'invalid' && <div className="estimate-box muted-box" data-testid="text-estimate-invalid">{rec.issues.length ? <ul className="issue-list">{rec.issues.map(i => <li key={i.field + i.message}>{i.message}</li>)}</ul> : 'Add age, height, and weight to see a recommendation.'}</div>}
    {rec.kind === 'minor' && <div className="estimate-box muted-box" data-testid="text-estimate-minor">Recommendations are only offered for adults 18 and over. A pediatric health professional can give guidance that fits.</div>}
    {rec.kind === 'blocked' && <div className="estimate-warn" role="alert" style={{ marginTop: 14 }}><AlertTriangle size={15} /> This estimate ({rec.calories.toLocaleString()} kcal/day) falls below {MIN_APPLY.toLocaleString()} kcal/day, so it can't be applied here. A qualified health professional can help set a target.</div>}
    {rec.kind === 'ok' && <div className="estimate-box" data-testid="text-estimate">
      <div className="estimate-main"><small>Preview</small><strong>{rec.calories.toLocaleString()} kcal/day</strong></div>
      <div className="rec-macros">
        <div><b>{rec.protein} g</b><span>Protein</span></div><div><b>{rec.carbs} g</b><span>Carbs</span></div><div><b>{rec.fat} g</b><span>Fat</span></div>
      </div>
      <details className="reasoning"><summary>How this was worked out</summary><ul>{rec.reasoning.map(r => <li key={r}>{r}</li>)}</ul></details>
      <button type="button" className="btn btn-primary btn-sm" disabled={applied} onClick={() => onApply({ calories: rec.calories, protein: rec.protein, carbs: rec.carbs, fat: rec.fat })} data-testid="button-apply-estimate">{applied ? 'These targets are in use' : 'Apply calories & all macros'}</button>
    </div>}
    <p className="fine-print">A starting point from general formulas, not medical advice. Your manual targets below stay exactly as saved until you apply a recommendation again.</p>
  </section>;
}

export function StepsCard() {
  return <section className="card steps-card" data-testid="card-steps">
    <div className="card-head"><div><h2>Steps</h2><p>Not available in the browser</p></div><span className="entry-icon"><Footprints size={17} /></span></div>
    <p className="fine-print" style={{ marginTop: 0 }}>Web browsers, including Safari on iPhone, can't read your pedometer or Apple Health. Habit Fuel does not guess or simulate step counts. Step counts are not supported on the web app; you can still log walks as movement here.</p>
    <span className="pill" data-testid="status-steps-unsupported">Unsupported on web</span>
  </section>;
}

export function InstallCard() {
  return <section className="card install-card" data-testid="card-install">
    <div className="card-head"><div><h2>Add to your iPhone Home Screen</h2><p>Opens full screen like an app. No App Store or Expo Go needed.</p></div></div>
    <ol className="install-steps">
      <li><span className="step-num">1</span><div>Once the app is published, open its <b>published https:// link</b> in <b>Safari</b>. Don't use the Replit editor preview or an Expo preview link.</div></li>
      <li><span className="step-num">2</span><div>Tap <b>Share</b> <Share size={14} className="inline-icon" /> in the toolbar.</div></li>
      <li><span className="step-num">3</span><div>Scroll and tap <b>Add to Home Screen</b> <SquarePlus size={14} className="inline-icon" />.</div></li>
      <li><span className="step-num">4</span><div>If you see <b>Open as Web App</b>, leave it on. Then tap <b>Add</b>.</div></li>
    </ol>
    <p className="fine-print">The Home Screen app keeps its own storage on some iOS versions, so entries made in Safari tabs may not appear there.</p>
  </section>;
}

export function SyncNotice() {
  return <section className="card data-card" data-testid="card-local-data">
    <div className="card-head"><div><h2>Where your data lives</h2><p>Your account, plus a cache on this device</p></div><span className="entry-icon"><Cloud size={17} /></span></div>
    <ul className="issue-list fine-print" style={{ marginTop: 0 }}>
      <li><b>Saved to your account</b> only once the status at the top says Synced. That copy is private to you and appears when you sign in on another device.</li>
      <li><b>Unsynced changes</b> (while offline, saving, or after a conflict) live only in this browser’s cache. If storage is blocked or full, they exist only in this open tab and are lost when it closes.</li>
      <li><b>Signing in needs a connection.</b> Offline, you can view the cached copy only after already being signed in here; editing resumes once the account reloads.</li>
    </ul>
  </section>;
}

export function GuestNotice() {
  return <section className="card data-card" data-testid="card-guest-data">
    <div className="card-head"><div><h2>Saved on this device only</h2><p>Guest mode · no account, no sync</p></div><span className="entry-icon"><HardDrive size={17} /></span></div>
    <ul className="issue-list fine-print" style={{ marginTop: 0 }}>
      <li>Logs, quick meals, plan, setup and theme stay in this browser. Nothing is sent to Habit Fuel servers.</li>
      <li>They are not backed up and don’t appear on other devices. Clearing site data or private browsing removes them.</li>
      <li>Creating an account later does not move these entries automatically. After signing in, Your setup offers an explicit import.</li>
    </ul>
  </section>;
}

export function LegacyImportCard({ legacy, onImport }: { legacy: Store; onImport: () => void }) {
  const [confirming, setConfirming] = useState(false);
  const count = legacy.foods.length + legacy.workouts.length + legacy.presets.length + legacy.plan.length;
  return <section className="card legacy-card" data-testid="card-legacy-import">
    <div className="card-head"><div><h2>Entries found in this browser</h2><p>From before accounts existed</p></div><span className="entry-icon"><HardDrive size={17} /></span></div>
    <p className="fine-print" style={{ marginTop: 0 }}>This browser holds {count} older {count === 1 ? 'item' : 'items'} ({legacy.foods.length} food, {legacy.workouts.length} movement, {legacy.presets.length} quick meals, {legacy.plan.length} plan). Only import them if they are yours. Duplicates are skipped, your profile and targets are not changed, and the original browser copy is left untouched.</p>
    {confirming ? <div className="row-gap"><button type="button" className="btn btn-primary btn-sm" onClick={() => { onImport(); setConfirming(false); }} data-testid="button-confirm-legacy-import">Yes, these are mine. Import</button><button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirming(false)}>Cancel</button></div>
      : <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirming(true)} data-testid="button-legacy-import"><Download size={14} /> Import into my account</button>}
  </section>;
}

const themeCards: { value: ThemeName; label: string; note: string }[] = [
  { value: 'classic', label: 'Garden', note: 'Sage and cream' },
  { value: 'dark', label: 'Evening', note: 'Low light, deep forest' },
  { value: 'lavender', label: 'Lavender', note: 'Soft lilac and oat' },
];
export function ThemePicker({ value, onChange }: { value: ThemeName; onChange: (t: ThemeName) => void }) {
  return <section className="card" data-testid="card-theme">
    <div className="card-head"><div><h2>Look and feel</h2><p>Applies right away and syncs with your account.</p></div></div>
    <div className="theme-grid" role="radiogroup" aria-label="Theme">{themeCards.map(t => <button type="button" role="radio" aria-checked={value === t.value} key={t.value} className={`theme-card ${value === t.value ? 'selected' : ''}`} onClick={() => onChange(t.value)} data-testid={`button-theme-${t.value}`}>
      <span className={`theme-swatch swatch-${t.value}`}><i /><i /><i /></span><b>{t.label}</b><small>{t.note}</small>{value === t.value && <Check size={14} className="theme-check" />}
    </button>)}</div>
  </section>;
}
