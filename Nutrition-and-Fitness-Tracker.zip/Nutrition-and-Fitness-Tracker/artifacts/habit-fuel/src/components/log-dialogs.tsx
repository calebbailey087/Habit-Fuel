import { useState, type FormEvent } from 'react';
import { Plus, X } from 'lucide-react';
import { Field, Modal, PhotoPicker } from './hf-ui';
import { newId, timeLabel, type Exercise, type FoodEntry, type MealPreset, type WorkoutEntry } from '@/lib/store';

export type FoodMode = 'manual' | 'label-photo' | 'meal-photo';
const asNum = (v: string) => { const n = Number(v); return Number.isFinite(n) && n > 0 ? n : 0; };

export function FoodDialog({ item, preset, mode, dateKey, onClose, onSave, onSavePreset }: { item: FoodEntry | null; preset?: MealPreset | null; mode: FoodMode; dateKey: string; onClose: () => void; onSave: (item: FoodEntry) => void; onSavePreset?: (p: MealPreset) => void }) {
  const src = item ?? preset ?? null;
  const [name, setName] = useState(src?.name ?? '');
  const [meal, setMeal] = useState(src?.meal ?? 'Breakfast');
  const [calories, setCalories] = useState(src ? String(src.calories) : '');
  const [protein, setProtein] = useState(src ? String(src.protein) : '');
  const [carbs, setCarbs] = useState(src ? String(src.carbs) : '');
  const [fat, setFat] = useState(src ? String(src.fat) : '');
  const [notes, setNotes] = useState(src?.notes ?? '');
  const [preview, setPreview] = useState('');
  const [error, setError] = useState('');
  const photoMode = mode !== 'manual';
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { setError('Add a name for this food.'); return; }
    if (calories.trim() === '' || !Number.isFinite(Number(calories)) || Number(calories) < 0) { setError('Enter calories yourself. Habit Fuel does not estimate nutrition from photos.'); return; }
    const values = { name: name.trim(), meal, calories: asNum(calories), protein: asNum(protein), carbs: asNum(carbs), fat: asNum(fat), notes: notes.trim() };
    if (preset && onSavePreset) { onSavePreset({ ...values, id: preset.id }); return; }
    onSave({ ...values, id: item?.id ?? newId(), dateKey: item?.dateKey ?? dateKey, time: item?.time ?? timeLabel(), estimateSource: item ? (item.estimateSource === 'meal-photo' ? 'meal-photo-user' : item.estimateSource) : mode === 'meal-photo' ? 'meal-photo-user' : mode });
  };
  const title = preset ? 'Edit quick meal' : item ? 'Edit food entry' : mode === 'label-photo' ? 'Add from a label photo' : mode === 'meal-photo' ? 'Add with a meal photo' : 'Add food';
  const copy = preset ? 'Changes apply to future quick-adds. Past entries stay as they were.' : mode === 'label-photo' ? 'The photo is just a reference while you type the values printed on the label.' : mode === 'meal-photo' ? 'The photo is context for you. You enter the nutrition values; nothing is estimated for you.' : 'Add a meal or snack. Nutrition values are yours to enter and adjust.';
  return <Modal title={title} copy={copy} onClose={onClose}>
    {photoMode && !item && <><div className="notice">No image analysis, label reading, or calorie estimation happens here. The photo is not saved with your entry.</div><PhotoPicker onChange={f => { if (f) setPreview(URL.createObjectURL(f)); }} preview={preview} label={mode === 'label-photo' ? 'Choose or take a label photo' : 'Choose or take a meal photo'} /></>}
    {item?.estimateSource === 'meal-photo' && <div className="notice">This older entry used a placeholder photo estimate from an earlier version. Saving will mark the values as yours; please check them.</div>}
    <form onSubmit={submit}><div className="form-grid">
      <div className="field full"><label>Food or meal name</label><input className="control" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. lentil soup and toast" data-testid="input-food-name" /></div>
      <div className="field"><label>Meal</label><select className="control" value={meal} onChange={e => setMeal(e.target.value)} data-testid="select-food-meal">{['Breakfast', 'Lunch', 'Dinner', 'Snack', 'Meal'].map(x => <option key={x}>{x}</option>)}</select></div>
      <Field label="Calories (kcal)" type="number" min="0" value={calories} onChange={setCalories} required testId="input-food-calories" />
      <Field label="Protein (g)" type="number" min="0" value={protein} onChange={setProtein} testId="input-food-protein" />
      <Field label="Carbs (g)" type="number" min="0" value={carbs} onChange={setCarbs} testId="input-food-carbs" />
      <Field label="Fat (g)" type="number" min="0" value={fat} onChange={setFat} testId="input-food-fat" />
      <div className="field full"><label>Notes (optional)</label><input className="control" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Serving size, ingredients, or anything useful" data-testid="input-food-notes" /></div>
    </div>
    {error && <div className="form-error" role="alert">{error}</div>}
    <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button className="btn btn-primary" data-testid="button-save-food">{preset ? 'Save quick meal' : item ? 'Save changes' : 'Add food'}</button></div></form>
  </Modal>;
}

type Draft = { key: string; name: string; sets: string; reps: string; weight: string };
const toDraft = (e?: Exercise): Draft => ({ key: newId(), name: e?.name ?? '', sets: e && e.sets ? String(e.sets) : '', reps: e && e.reps ? String(e.reps) : '', weight: e && e.weight ? String(e.weight) : '' });

export function WorkoutDialog({ item, dateKey, onClose, onSave }: { item: WorkoutEntry | null; dateKey: string; onClose: () => void; onSave: (item: WorkoutEntry) => void }) {
  const [name, setName] = useState(item?.name ?? '');
  const [type, setType] = useState(item?.type ?? 'Strength');
  const [duration, setDuration] = useState(String(item?.durationMinutes ?? 30));
  const [effort, setEffort] = useState(item?.effort ?? 'Moderate');
  const [burn, setBurn] = useState(String(item?.caloriesBurnedEstimate ?? 120));
  const [rows, setRows] = useState<Draft[]>(() => item?.exercises.length ? item.exercises.map(toDraft) : []);
  const patch = (key: string, p: Partial<Draft>) => setRows(r => r.map(x => x.key === key ? { ...x, ...p } : x));
  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSave({ id: item?.id ?? newId(), dateKey: item?.dateKey ?? dateKey, name: name.trim(), type, durationMinutes: asNum(duration), effort, caloriesBurnedEstimate: asNum(burn),
      exercises: rows.filter(r => r.name.trim()).map(r => ({ name: r.name.trim(), sets: Math.round(asNum(r.sets)), reps: Math.round(asNum(r.reps)), weight: asNum(r.weight) })) });
  };
  return <Modal title={item ? 'Edit workout' : 'Log a workout'} copy="Track the movement you did. Burn is only a rough estimate and stays separate from food." onClose={onClose}>
    <form onSubmit={submit}><div className="form-grid">
      <div className="field full"><label>Workout name</label><input required className="control" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Park walk, strength session" data-testid="input-workout-name" /></div>
      <div className="field"><label>Type</label><select className="control" value={type} onChange={e => setType(e.target.value)} data-testid="select-workout-type">{['Strength', 'Walk', 'Run', 'Cycle', 'Yoga & mobility', 'Sport', 'Other'].map(x => <option key={x}>{x}</option>)}</select></div>
      <Field label="Duration (minutes)" type="number" min="0" inputMode="numeric" value={duration} onChange={setDuration} testId="input-workout-duration" />
      <div className="field"><label>Effort</label><select className="control" value={effort} onChange={e => setEffort(e.target.value)} data-testid="select-workout-effort">{['Easy', 'Moderate', 'Hard'].map(x => <option key={x}>{x}</option>)}</select></div>
      <Field label="Burn estimate (kcal)" type="number" min="0" inputMode="numeric" value={burn} onChange={setBurn} testId="input-workout-burn" />
    </div>
    <div className="exercise-block">
      <div className="exercise-head"><h3>Exercises</h3><span className="pill">Optional · {rows.length}</span></div>
      {rows.length === 0 && <p className="exercise-empty">Add exercises to remember sets, reps, and weight for next time.</p>}
      {rows.map((r, i) => <div className="exercise-row" key={r.key} data-testid={`row-exercise-${i}`}>
        <div className="exercise-row-top"><span className="exercise-num">{i + 1}</span><input className="control" value={r.name} onChange={e => patch(r.key, { name: e.target.value })} placeholder="e.g. Goblet squat" aria-label={`Exercise ${i + 1} name`} data-testid={`input-exercise-name-${i}`} /><button type="button" className="icon-button" aria-label={`Remove exercise ${i + 1}`} onClick={() => setRows(rs => rs.filter(x => x.key !== r.key))} data-testid={`button-remove-exercise-${i}`}><X size={16} /></button></div>
        <div className="exercise-nums">
          <label><span>Sets</span><input className="control" type="number" min="0" inputMode="numeric" value={r.sets} onChange={e => patch(r.key, { sets: e.target.value })} placeholder="3" data-testid={`input-exercise-sets-${i}`} /></label>
          <label><span>Reps</span><input className="control" type="number" min="0" inputMode="numeric" value={r.reps} onChange={e => patch(r.key, { reps: e.target.value })} placeholder="10" data-testid={`input-exercise-reps-${i}`} /></label>
          <label><span>Weight (lb)</span><input className="control" type="number" min="0" step="0.5" inputMode="decimal" value={r.weight} onChange={e => patch(r.key, { weight: e.target.value })} placeholder="Optional" data-testid={`input-exercise-weight-${i}`} /></label>
        </div>
      </div>)}
      <button type="button" className="btn btn-secondary btn-sm add-exercise" onClick={() => setRows(rs => [...rs, toDraft()])} data-testid="button-add-exercise"><Plus size={15} /> {rows.length ? 'Add another exercise' : 'Add an exercise'}</button>
    </div>
    <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button><button className="btn btn-primary" data-testid="button-save-workout">{item ? 'Save changes' : 'Add workout'}</button></div></form>
  </Modal>;
}
