import { useEffect, useState, type ReactNode } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import { Activity, CalendarDays, Sparkles, UserRound, Utensils } from 'lucide-react';
import { useTodayKey } from '@/hooks/use-today-key';
import { formatKey, type Shared, type Store } from '@/lib/store';
import { CoachPage, Dashboard, NotFound, PlansPage } from '@/pages/app-pages';
import { LogPage } from '@/pages/log-page';
import { ProfilePage, type Identity } from '@/pages/profile-page';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

const navLinks = [
  { href: '/today', label: 'Today', short: 'Today', icon: CalendarDays },
  { href: '/log', label: 'My log', short: 'Log', icon: Utensils },
  { href: '/plans', label: 'My plan', short: 'Plan', icon: Activity },
  { href: '/coach', label: 'Coach notes', short: 'Coach', icon: Sparkles },
  { href: '/profile', label: 'Your setup', short: 'You', icon: UserRound },
];

export function initialsOf(name: string, fallback: string) {
  const src = name.trim() || fallback || 'HF';
  const parts = src.split(/\s+/).filter(Boolean);
  return ((parts[0]?.[0] ?? 'H') + (parts[1]?.[0] ?? parts[0]?.[1] ?? '')).toUpperCase();
}

/**
 * Shared app chrome + pages, used by both account and guest modes.
 * Routes are relative to whatever Wouter base wraps it.
 */
export function AppShell({ store, update, statusChip, banners, identity, dataNotice, allowLegacyImport, name }: {
  store: Store;
  update: (patch: Partial<Store>) => boolean;
  statusChip: ReactNode;
  banners?: ReactNode;
  identity: Omit<Identity, 'initials'>;
  dataNotice: ReactNode;
  allowLegacyImport: boolean;
  name: string;
}) {
  const todayKey = useTodayKey();
  const [location] = useLocation();
  const [toast, setToast] = useState('');
  const theme = store.theme;
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => () => { document.documentElement.dataset.theme = 'classic'; }, []);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(''), 2800); return () => window.clearTimeout(t); }, [toast]);

  const notify = (m: string) => setToast(m);
  const shared: Shared = { store, update: patch => { if (!update(patch)) notify('Reconnect to make changes. Showing your cached copy for now.'); }, notify, todayKey };
  const initials = initialsOf(name, identity.badge ?? identity.subtitle);

  return <div className="app-shell">
    <aside className="sidebar">
      <Link href="/today" className="brand"><span className="brand-mark"><img src={`${basePath}/logo.svg`} alt="" width={36} height={36} style={{ borderRadius: 12 }} /></span><span><strong>habit fuel</strong><small>steady looks good</small></span></Link>
      <div className="nav-label">Your space</div>
      <nav className="nav-list">{navLinks.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`link-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={17} strokeWidth={1.8} />{label}</Link>)}</nav>
      <div className="side-note"><div className="tiny">A small reminder</div><p>There is no perfect day. Just the next choice that feels right for you.</p></div>
    </aside>
    <main className="main">
      <header className="topbar">
        <div className="topbar-date">{formatKey(todayKey, { weekday: 'long', month: 'long', day: 'numeric' })}</div>
        <div className="top-right">
          {statusChip}
          <Link href="/profile" className="top-user"><span className="greet">{name ? `Hi, ${name.split(' ')[0]}` : 'Your setup'}</span><span className="avatar">{initials}</span></Link>
        </div>
      </header>
      {banners}
      <Switch>
        <Route path="/today"><Dashboard {...shared} /></Route>
        <Route path="/log"><LogPage {...shared} /></Route>
        <Route path="/plans"><PlansPage {...shared} /></Route>
        <Route path="/coach"><CoachPage {...shared} /></Route>
        <Route path="/profile"><ProfilePage {...shared} identity={{ ...identity, initials }} dataNotice={dataNotice} allowLegacyImport={allowLegacyImport} /></Route>
        <Route><NotFound /></Route>
      </Switch>
    </main>
    <nav className="mobile-nav">{navLinks.map(({ href, short, icon: Icon }) => <Link key={href} href={href} className={location === href ? 'active' : ''}><Icon size={18} />{short}</Link>)}</nav>
    {toast && <div className="toast" role="status" data-testid="status-toast">{toast}</div>}
  </div>;
}
