import { Bookmark, Edit3, Plus, Trash2 } from 'lucide-react';
import { money, type FoodEntry, type MealPreset } from '@/lib/store';

export const presetMatches = (p: MealPreset, f: FoodEntry) => p.name.trim().toLowerCase() === f.name.trim().toLowerCase() && p.meal === f.meal;

export function MealPresets({ presets, onAdd, onEdit, onDelete }: { presets: MealPreset[]; onAdd: (p: MealPreset) => void; onEdit: (p: MealPreset) => void; onDelete: (p: MealPreset) => void }) {
  return <section className="card presets-card" data-testid="card-meal-presets">
    <div className="card-head"><div><h2>Quick meals</h2><p>Saved favorites. Adding one logs it today at the current time.</p></div><span className="pill"><Bookmark size={12} /> {presets.length} saved</span></div>
    {presets.length === 0 ? <p className="presets-empty">Tap the bookmark on any logged food to keep it here for next time.</p> :
      <div className="preset-list">{presets.map(p => <div className="preset-row" key={p.id} data-testid={`row-preset-${p.id}`}>
        <div className="row-copy"><div className="row-title">{p.name}</div><div className="row-detail">{p.meal} · {money(p.calories)} kcal · P {p.protein}g · C {p.carbs}g · F {p.fat}g</div></div>
        <div className="preset-actions">
          <button className="btn btn-primary btn-sm" onClick={() => onAdd(p)} data-testid={`button-quick-add-${p.id}`}><Plus size={14} /> Add</button>
          <button className="icon-button" aria-label={`Edit ${p.name} quick meal`} onClick={() => onEdit(p)} data-testid={`button-edit-preset-${p.id}`}><Edit3 size={15} /></button>
          <button className="icon-button" aria-label={`Delete ${p.name} quick meal`} onClick={() => onDelete(p)} data-testid={`button-delete-preset-${p.id}`}><Trash2 size={15} /></button>
        </div>
      </div>)}</div>}
  </section>;
}
