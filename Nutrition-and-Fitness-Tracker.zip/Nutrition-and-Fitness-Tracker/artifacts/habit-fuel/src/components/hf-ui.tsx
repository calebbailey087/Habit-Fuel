import { useEffect, useRef, type ReactNode } from 'react';
import { Link } from 'wouter';
import { ImagePlus, Leaf, X } from 'lucide-react';

export function PageHead({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy: string; action?: ReactNode }) {
  return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="subhead">{copy}</p></div>{action}</div>;
}
export function Empty({ title, copy, button, href }: { title: string; copy: string; button?: string; href?: string }) {
  return <div className="empty"><Leaf size={22} /><strong>{title}</strong><p>{copy}</p>{button && href && <Link href={href} className="btn btn-secondary btn-sm">{button}</Link>}</div>;
}
export function Field({ label, value, onChange, type = 'text', placeholder, min, max, step, required = false, inputMode, testId }: { label: string; value: string | number; onChange: (value: string) => void; type?: string; placeholder?: string; min?: string; max?: string; step?: string; required?: boolean; inputMode?: 'numeric' | 'decimal' | 'text'; testId?: string }) {
  return <div className="field"><label>{label}</label><input aria-label={label} className="control" type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} min={min} max={max} step={step ?? (type === 'number' ? 'any' : undefined)} required={required} inputMode={inputMode ?? (type === 'number' ? 'decimal' : undefined)} data-testid={testId} /></div>;
}
export function Modal({ title, copy, onClose, children }: { title: string; copy: string; onClose: () => void; children: ReactNode }) {
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeRef.current(); };
    window.addEventListener('keydown', onKey);
    document.body.classList.add('modal-open');
    return () => { window.removeEventListener('keydown', onKey); document.body.classList.remove('modal-open'); };
  }, []);
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="modal" role="dialog" aria-modal="true" aria-label={title}><div className="modal-head"><div><div className="eyebrow">Your log</div><h2>{title}</h2><p>{copy}</p></div><button type="button" className="close-btn" onClick={onClose} aria-label="Close" data-testid="button-close-modal"><X size={20} /></button></div>{children}</section></div>;
}
export function PhotoPicker({ onChange, preview, label }: { onChange: (file?: File) => void; preview?: string; label: string }) {
  return <label className="photo-drop" data-testid="input-photo"><ImagePlus size={22} className="photo-icon" /><strong>{label}</strong><span>Shown only in this tab. Never uploaded, saved, or analyzed.</span><input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => onChange(e.target.files?.[0])} />{preview && <img className="photo-preview" src={preview} alt="Selected food" />}</label>;
}
