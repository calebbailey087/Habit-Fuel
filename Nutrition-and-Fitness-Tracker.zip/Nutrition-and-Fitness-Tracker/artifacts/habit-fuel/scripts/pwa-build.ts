import { createHash } from 'node:crypto';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import type { Plugin } from 'vite';

// Generate the worker after Vite hashes its assets, so each release has a
// complete, versioned app shell. No API responses or personal logs are cached.
export function pwaBuild(): Plugin {
  let outputDir = '';
  let base = '/';
  return {
    name: 'habit-fuel-offline-shell',
    apply: 'build',
    configResolved(config) {
      outputDir = path.resolve(config.root, config.build.outDir);
      base = config.base.endsWith('/') ? config.base : `${config.base}/`;
    },
    async closeBundle() {
      async function filesIn(directory: string, prefix = ''): Promise<string[]> {
        const entries = await readdir(directory, { withFileTypes: true });
        const groups = await Promise.all(entries.map(async (entry) => {
          const relative = `${prefix}${entry.name}`;
          return entry.isDirectory()
            ? filesIn(path.join(directory, entry.name), `${relative}/`)
            : [relative];
        }));
        return groups.flat();
      }
      const files = (await filesIn(outputDir)).filter((file) => file !== 'sw.js' && !file.endsWith('.map')).sort();
      const hash = createHash('sha256');
      for (const file of files) {
        hash.update(file);
        hash.update(await readFile(path.join(outputDir, file)));
      }
      const version = hash.digest('hex').slice(0, 16);
      const worker = `
const CACHE = ${JSON.stringify(`habit-fuel-pwa-${version}`)};
const FILES = ${JSON.stringify(files.map((file) => `${base}${file}`))};
const SHELL = ${JSON.stringify(`${base}index.html`)};
const ROUTES = new Set(['', 'today', 'log', 'plans', 'coach', 'profile', 'guest', 'guest/today', 'guest/log', 'guest/plans', 'guest/coach', 'guest/profile']);
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(FILES)));
});
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('habit-fuel-pwa-') && key !== CACHE).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  const scope = new URL(self.registration.scope);
  if (request.method !== 'GET' || url.origin !== scope.origin || !url.pathname.startsWith(scope.pathname)) return;
  const relative = url.pathname.slice(scope.pathname.length).replace(/\\/$/, '');
  if (request.mode === 'navigate' && ROUTES.has(relative)) {
    event.respondWith(fetch(request).catch(async () => {
      const cache = await caches.open(CACHE);
      const shell = await cache.match(SHELL);
      return shell || Response.error();
    }));
    return;
  }
  if (FILES.includes(url.pathname)) {
    event.respondWith(caches.open(CACHE).then(async (cache) => (await cache.match(request)) || fetch(request)));
  }
});
`;
      await writeFile(path.join(outputDir, 'sw.js'), worker);
    },
  };
}
