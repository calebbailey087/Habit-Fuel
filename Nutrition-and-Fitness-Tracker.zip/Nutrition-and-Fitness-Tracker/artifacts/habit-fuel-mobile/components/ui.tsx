import { Feather } from '@expo/vector-icons';
import type { ReactNode } from 'react';
import {
  Platform,
  Pressable,
  Text,
  TextInput,
  type TextInputProps,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

export function AppScreen({
  eyebrow,
  title,
  subtitle,
  children,
  right,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
  right?: ReactNode;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <KeyboardAwareScrollViewCompat
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{
        paddingHorizontal: 20,
        paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12,
        paddingBottom: Platform.OS === 'web' ? 110 : 32,
        gap: 18,
      }}
      bottomOffset={32}
      keyboardShouldPersistTaps="handled"
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <View style={{ flex: 1, gap: 5 }}>
          {eyebrow ? <Text style={{ color: colors.mutedForeground, fontSize: 11, fontFamily: 'DMSans_700Bold', letterSpacing: 1.5 }}>{eyebrow}</Text> : null}
          <Text accessibilityRole="header" style={{ color: colors.foreground, fontSize: 30, lineHeight: 36, fontFamily: 'DMSans_700Bold' }}>{title}</Text>
          {subtitle ? <Text style={{ color: colors.mutedForeground, fontSize: 15, lineHeight: 22, fontFamily: 'DMSans_400Regular' }}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
      {children}
    </KeyboardAwareScrollViewCompat>
  );
}

export function Card({ children, style, testID }: { children: ReactNode; style?: object; testID?: string }) {
  const colors = useColors();
  return (
    <View
      testID={testID}
      style={[
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderWidth: 1,
          borderRadius: colors.radius + 8,
          padding: 18,
          gap: 12,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({ title, right }: { title: string; right?: ReactNode }) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
      <Text style={{ color: colors.foreground, fontSize: 19, fontFamily: 'DMSans_700Bold' }}>{title}</Text>
      {right}
    </View>
  );
}

export function AppButton({
  label,
  onPress,
  icon,
  tone = 'primary',
  disabled = false,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Feather.glyphMap;
  tone?: 'primary' | 'soft' | 'outline' | 'danger';
  disabled?: boolean;
  testID: string;
}) {
  const colors = useColors();
  const backgroundColor =
    tone === 'primary' ? colors.primary : tone === 'danger' ? colors.destructive : tone === 'soft' ? colors.secondary : 'transparent';
  const color = tone === 'primary' ? colors.primaryForeground : tone === 'danger' ? colors.destructiveForeground : colors.foreground;
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: 48,
        paddingHorizontal: 16,
        borderRadius: colors.radius,
        borderWidth: tone === 'outline' ? 1 : 0,
        borderColor: colors.border,
        backgroundColor: tone === 'outline' ? 'transparent' : backgroundColor,
        opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 9,
      })}
    >
      {icon ? <Feather name={icon} size={17} color={color} /> : null}
      <Text style={{ color, fontSize: 14, fontFamily: 'DMSans_700Bold' }}>{label}</Text>
    </Pressable>
  );
}

export function IconButton({
  icon,
  onPress,
  label,
  testID,
  destructive = false,
}: {
  icon: keyof typeof Feather.glyphMap;
  onPress: () => void;
  label: string;
  testID: string;
  destructive?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      hitSlop={8}
      style={({ pressed }) => ({ padding: 8, opacity: pressed ? 0.55 : 1 })}
    >
      <Feather name={icon} size={17} color={destructive ? colors.destructive : colors.mutedForeground} />
    </Pressable>
  );
}

export function ChoiceChip({
  label,
  selected,
  onPress,
  testID,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  testID: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => ({
        paddingHorizontal: 13,
        paddingVertical: 10,
        borderRadius: 22,
        borderWidth: 1,
        borderColor: selected ? colors.primary : colors.border,
        backgroundColor: selected ? colors.primary : colors.card,
        opacity: pressed ? 0.78 : 1,
      })}
    >
      <Text style={{ fontFamily: 'DMSans_600SemiBold', fontSize: 13, color: selected ? colors.primaryForeground : colors.foreground }}>{label}</Text>
    </Pressable>
  );
}

export function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = 'default',
  multiline = false,
  testID,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  keyboardType?: TextInputProps['keyboardType'];
  multiline?: boolean;
  testID: string;
}) {
  const colors = useColors();
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>{label}</Text>
      <TextInput
        testID={testID}
        accessibilityLabel={label}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        keyboardType={keyboardType}
        multiline={multiline}
        textAlignVertical={multiline ? 'top' : 'center'}
        style={{
          color: colors.foreground,
          backgroundColor: colors.background,
          borderColor: colors.input,
          borderWidth: 1,
          borderRadius: colors.radius,
          minHeight: multiline ? 92 : 48,
          paddingHorizontal: 13,
          paddingVertical: multiline ? 12 : 0,
          fontSize: 15,
          fontFamily: 'DMSans_400Regular',
        }}
      />
    </View>
  );
}

export function ProgressBar({ value, max, color }: { value: number; max: number; color?: string }) {
  const colors = useColors();
  const width = `${Math.min(100, Math.max(0, max > 0 ? (value / max) * 100 : 0))}%` as `${number}%`;
  return (
    <View style={{ height: 8, borderRadius: 8, backgroundColor: colors.secondary, overflow: 'hidden' }}>
      <View style={{ width, height: '100%', borderRadius: 8, backgroundColor: color ?? colors.primary }} />
    </View>
  );
}

export function MutedText({ children, style }: { children: ReactNode; style?: object }) {
  const colors = useColors();
  return <Text style={[{ color: colors.mutedForeground, fontSize: 13, lineHeight: 19, fontFamily: 'DMSans_400Regular' }, style]}>{children}</Text>;
}

export function LabelPill({ children, color }: { children: ReactNode; color?: string }) {
  const colors = useColors();
  return (
    <View style={{ alignSelf: 'flex-start', backgroundColor: color ?? colors.secondary, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 5 }}>
      <Text style={{ color: colors.foreground, fontSize: 11, fontFamily: 'DMSans_700Bold' }}>{children}</Text>
    </View>
  );
}
