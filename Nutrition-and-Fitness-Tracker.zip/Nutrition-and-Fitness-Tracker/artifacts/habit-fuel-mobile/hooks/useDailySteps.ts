import { Pedometer } from 'expo-sensors';
import { AppState, Platform } from 'react-native';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useAppState } from '@/context/AppState';

type StepStatus = 'off' | 'loading' | 'connected' | 'unsupported' | 'permission-denied' | 'error';

function localMidnight() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

export function useDailySteps() {
  const { stepTrackingEnabled, setStepTrackingEnabled, addStepCount, stepCounts, todayKey } = useAppState();
  const stepCountsRef = useRef(stepCounts);
  stepCountsRef.current = stepCounts;
  const addStepCountRef = useRef(addStepCount);
  addStepCountRef.current = addStepCount;
  const lastObservedAndroidSteps = useRef(0);
  const [steps, setSteps] = useState<number | null>(null);
  const [status, setStatus] = useState<StepStatus>(stepTrackingEnabled ? 'loading' : 'off');

  const refresh = useCallback(async () => {
    if (!stepTrackingEnabled) return;
    if (Platform.OS === 'web') {
      setStatus('unsupported');
      return;
    }
    try {
      setStatus('loading');
      const available = await Pedometer.isAvailableAsync();
      if (!available) {
        setStatus('unsupported');
        return;
      }
      const permission = await Pedometer.getPermissionsAsync();
      if (!permission.granted) {
        setSteps(null);
        setStatus('permission-denied');
        return;
      }
      if (Platform.OS === 'ios') {
        const result = await Pedometer.getStepCountAsync(localMidnight(), new Date());
        setSteps(result.steps);
      } else {
        setSteps(stepCountsRef.current[todayKey] ?? 0);
      }
      setStatus('connected');
    } catch {
      setStatus('error');
    }
  }, [stepTrackingEnabled, todayKey]);

  const enable = useCallback(async () => {
    if (Platform.OS === 'web') {
      setStatus('unsupported');
      return;
    }
    try {
      setStatus('loading');
      const available = await Pedometer.isAvailableAsync();
      if (!available) {
        setStatus('unsupported');
        return;
      }
      const permission = await Pedometer.requestPermissionsAsync();
      if (!permission.granted) {
        setSteps(null);
        setStatus('permission-denied');
        return;
      }
      setStepTrackingEnabled(true);
      if (Platform.OS === 'ios') {
        const result = await Pedometer.getStepCountAsync(localMidnight(), new Date());
        setSteps(result.steps);
      } else {
        lastObservedAndroidSteps.current = 0;
        setSteps(stepCountsRef.current[todayKey] ?? 0);
      }
      setStatus('connected');
    } catch {
      setStatus('error');
    }
  }, [setStepTrackingEnabled]);

  const disable = useCallback(() => {
    setStepTrackingEnabled(false);
    setSteps(null);
    setStatus('off');
  }, [setStepTrackingEnabled]);

  useEffect(() => {
    if (!stepTrackingEnabled || Platform.OS === 'web') return;
    void refresh();
    lastObservedAndroidSteps.current = 0;
    const subscription = Pedometer.watchStepCount((result) => {
      if (Platform.OS === 'android') {
        const delta = Math.max(0, result.steps - lastObservedAndroidSteps.current);
        lastObservedAndroidSteps.current = result.steps;
        if (delta > 0) {
          addStepCountRef.current(todayKey, delta);
          setSteps((stepCountsRef.current[todayKey] ?? 0) + delta);
        }
        setStatus('connected');
        return;
      }
      void refresh();
    });
    const appStateSubscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') void refresh();
    });
    return () => {
      subscription.remove();
      appStateSubscription.remove();
    };
  }, [refresh, stepTrackingEnabled, todayKey]);

  return { steps, status, enable, disable, refresh };
}
