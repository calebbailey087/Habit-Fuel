/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#243831',
    tint: '#336c57',
    background: '#f9f7f0',
    foreground: '#243831',
    card: '#fdfdfb',
    cardForeground: '#243831',
    primary: '#336c57',
    primaryForeground: '#fbf9f4',
    secondary: '#f0ece6',
    secondaryForeground: '#243831',
    muted: '#f0ece6',
    mutedForeground: '#677e74',
    accent: '#d97b5e',
    accentForeground: '#fbf9f4',
    destructive: '#cf3830',
    destructiveForeground: '#ffffff',
    border: '#e3ded3',
    input: '#e3ded3',
  },
  dark: {
    text: '#f5f2ea',
    tint: '#5fb495',
    background: '#182520',
    foreground: '#f5f2ea',
    card: '#21312b',
    cardForeground: '#f5f2ea',
    primary: '#5fb495',
    primaryForeground: '#182520',
    secondary: '#30403a',
    secondaryForeground: '#f5f2ea',
    muted: '#30403a',
    mutedForeground: '#a5b6ae',
    accent: '#db8166',
    accentForeground: '#182520',
    destructive: '#d34c45',
    destructiveForeground: '#ffffff',
    border: '#3e514a',
    input: '#3e514a',
  },
  radius: 16,
};

export default colors;
