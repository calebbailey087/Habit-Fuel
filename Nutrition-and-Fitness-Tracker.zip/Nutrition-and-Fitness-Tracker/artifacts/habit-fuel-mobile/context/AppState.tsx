import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createContext,
  type ReactNode,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { AppState as DeviceAppState } from 'react-native';

export type FoodSource = 'manual' | 'meal-photo' | 'label-photo';
export type Effort = 'Easy' | 'Moderate' | 'Hard';
export type WeightGoal = 'lose' | 'maintain' | 'gain';
export type CalorieEquation = 'range' | 'female' | 'male';

export interface FoodEntry {
  id: string;
  dateKey: string;
  name: string;
  meal: string;
  time: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  source: FoodSource;
}

export interface FoodPreset {
  id: string;
  name: string;
  meal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  source: FoodSource;
}

export interface ExerciseSet {
  name: string;
  sets: number;
  reps: number;
  weight: number;
}

export interface WorkoutEntry {
  id: string;
  dateKey: string;
  name: string;
  type: string;
  durationMinutes: number;
  effort: Effort;
  caloriesBurnedEstimate: number;
  exercises: ExerciseSet[];
}

export interface PlanItem {
  id: string;
  name: string;
  day: string;
  durationMinutes: number;
  completed: boolean;
}

export interface Profile {
  goal: string;
  experience: string;
  routineMode: string;
  daysAvailable: string[];
  equipment: string[];
  movementNotes: string;
  ageYears: number | null;
  heightFeet: number | null;
  heightInches: number | null;
  weightPounds: number | null;
  activityLevel: string;
  calorieEquation: CalorieEquation;
  weightGoal: WeightGoal;
}

export interface NutritionTargets {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface AppData {
  hasCompletedOnboarding: boolean;
  foodEntries: FoodEntry[];
  foodPresets: FoodPreset[];
  workoutEntries: WorkoutEntry[];
  planItems: PlanItem[];
  profile: Profile;
  targets: NutritionTargets;
  stepTrackingEnabled: boolean;
  stepCounts: Record<string, number>;
}

interface AppStateValue extends AppData {
  ready: boolean;
  storageError: string | null;
  todayKey: string;
  addFood: (entry: Omit<FoodEntry, 'id' | 'dateKey'>) => void;
  updateFood: (id: string, patch: Partial<Omit<FoodEntry, 'id'>>) => void;
  removeFood: (id: string) => void;
  addFoodPreset: (entry: Omit<FoodPreset, 'id'>) => void;
  addFoodFromPreset: (id: string) => void;
  removeFoodPreset: (id: string) => void;
  addWorkout: (entry: Omit<WorkoutEntry, 'id' | 'dateKey'>) => void;
  updateWorkout: (id: string, patch: Partial<Omit<WorkoutEntry, 'id'>>) => void;
  removeWorkout: (id: string) => void;
  addPlanItem: (entry: Omit<PlanItem, 'id' | 'completed'>) => void;
  togglePlanItem: (id: string) => void;
  removePlanItem: (id: string) => void;
  updateProfile: (patch: Partial<Profile>) => void;
  updateTargets: (patch: Partial<NutritionTargets>) => void;
  setStepTrackingEnabled: (enabled: boolean) => void;
  addStepCount: (dateKey: string, count: number) => void;
  completeOnboarding: () => void;
}

const STORAGE_KEY = 'habit-fuel-native-v1';

const createId = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export function getLocalDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function currentTimeLabel() {
  return new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function createInitialData(): AppData {
  const todayKey = getLocalDateKey(new Date());
  return {
    hasCompletedOnboarding: false,
    foodEntries: [
      {
        id: 'food-breakfast',
        dateKey: todayKey,
        name: 'Greek yogurt, berries & oats',
        meal: 'Breakfast',
        time: '8:10 AM',
        calories: 385,
        protein: 24,
        carbs: 44,
        fat: 11,
        source: 'manual',
      },
      {
        id: 'food-lunch',
        dateKey: todayKey,
        name: 'Chicken grain bowl',
        meal: 'Lunch',
        time: '12:35 PM',
        calories: 610,
        protein: 34,
        carbs: 70,
        fat: 21,
        source: 'manual',
      },
      {
        id: 'food-snack',
        dateKey: todayKey,
        name: 'Apple & almond butter',
        meal: 'Snack',
        time: '3:05 PM',
        calories: 220,
        protein: 10,
        carbs: 26,
        fat: 12,
        source: 'manual',
      },
    ],
    workoutEntries: [
      {
        id: 'workout-walk',
        dateKey: todayKey,
        name: 'Easy afternoon walk',
        type: 'Walking',
        durationMinutes: 20,
        effort: 'Easy',
        caloriesBurnedEstimate: 104,
        exercises: [],
      },
    ],
    foodPresets: [
      {
        id: 'preset-breakfast-demo',
        name: 'Greek yogurt, berries & oats',
        meal: 'Breakfast',
        calories: 385,
        protein: 24,
        carbs: 44,
        fat: 11,
        source: 'manual',
      },
    ],
    planItems: [
      { id: 'plan-1', name: 'Full-body strength', day: 'Monday', durationMinutes: 35, completed: true },
      { id: 'plan-2', name: 'Mobility & stretch', day: 'Wednesday', durationMinutes: 20, completed: false },
      { id: 'plan-3', name: 'A walk that feels good', day: 'Saturday', durationMinutes: 30, completed: false },
    ],
    profile: {
      goal: 'Build consistent habits',
      experience: 'Returning / occasional',
      routineMode: 'Help me adapt my routine',
      daysAvailable: ['Monday', 'Wednesday', 'Saturday'],
      equipment: ['Bodyweight', 'Dumbbells'],
      movementNotes: '',
      ageYears: null,
      heightFeet: null,
      heightInches: null,
      weightPounds: null,
      activityLevel: 'Lightly active',
      calorieEquation: 'range',
      weightGoal: 'maintain',
    },
    targets: { calories: 2050, protein: 110, carbs: 235, fat: 70 },
    stepTrackingEnabled: false,
    stepCounts: {},
  };
}

const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(createInitialData);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [todayKey, setTodayKey] = useState(() => getLocalDateKey(new Date()));

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((saved) => {
        if (!active || !saved) return;
        try {
          const parsed = JSON.parse(saved) as Partial<AppData>;
          const initial = createInitialData();
          const migratedDayKey = getLocalDateKey(new Date());
          setData({
            ...initial,
            ...parsed,
            profile: { ...initial.profile, ...parsed.profile },
            targets: { ...initial.targets, ...parsed.targets },
            foodEntries: (parsed.foodEntries ?? initial.foodEntries).map((entry) => ({
              ...entry,
              dateKey: entry.dateKey ?? migratedDayKey,
            })),
            foodPresets: parsed.foodPresets ?? initial.foodPresets,
            workoutEntries: (parsed.workoutEntries ?? initial.workoutEntries).map((entry) => ({
              ...entry,
              dateKey: entry.dateKey ?? migratedDayKey,
              exercises: entry.exercises ?? [],
            })),
            planItems: parsed.planItems ?? initial.planItems,
            stepCounts: parsed.stepCounts ?? initial.stepCounts,
          });
        } catch {
          setStorageError('Saved data could not be read. Your sample entries are still available.');
        }
      })
      .catch(() => {
        if (active) setStorageError('Device storage is unavailable. Changes may not persist.');
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const refreshDay = () => {
      const now = new Date();
      setTodayKey(getLocalDateKey(now));
      const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      timer = setTimeout(refreshDay, Math.max(1000, nextMidnight.getTime() - now.getTime() + 100));
    };

    refreshDay();
    const subscription = DeviceAppState.addEventListener('change', (state) => {
      if (state === 'active') {
        clearTimeout(timer);
        refreshDay();
      }
    });
    return () => {
      clearTimeout(timer);
      subscription.remove();
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => {
      setStorageError('Changes could not be saved to this device.');
    });
  }, [data, ready]);

  const value = useMemo<AppStateValue>(
    () => ({
      ...data,
      ready,
      storageError,
      todayKey,
      addFood: (entry) =>
        setData((current) => ({
          ...current,
          foodEntries: [{ ...entry, id: createId(), dateKey: getLocalDateKey(new Date()) }, ...current.foodEntries],
        })),
      updateFood: (id, patch) =>
        setData((current) => ({
          ...current,
          foodEntries: current.foodEntries.map((entry) => (entry.id === id ? { ...entry, ...patch } : entry)),
        })),
      removeFood: (id) =>
        setData((current) => ({ ...current, foodEntries: current.foodEntries.filter((entry) => entry.id !== id) })),
      addFoodPreset: (entry) =>
        setData((current) => {
          const duplicate = current.foodPresets.some(
            (preset) => preset.name.trim().toLowerCase() === entry.name.trim().toLowerCase() && preset.meal === entry.meal,
          );
          return duplicate
            ? current
            : { ...current, foodPresets: [{ ...entry, id: createId() }, ...current.foodPresets] };
        }),
      addFoodFromPreset: (id) =>
        setData((current) => {
          const preset = current.foodPresets.find((entry) => entry.id === id);
          if (!preset) return current;
          const { id: _presetId, ...food } = preset;
          return {
            ...current,
            foodEntries: [
              { ...food, id: createId(), dateKey: getLocalDateKey(new Date()), time: currentTimeLabel() },
              ...current.foodEntries,
            ],
          };
        }),
      removeFoodPreset: (id) =>
        setData((current) => ({ ...current, foodPresets: current.foodPresets.filter((entry) => entry.id !== id) })),
      addWorkout: (entry) =>
        setData((current) => ({
          ...current,
          workoutEntries: [{ ...entry, id: createId(), dateKey: getLocalDateKey(new Date()) }, ...current.workoutEntries],
        })),
      updateWorkout: (id, patch) =>
        setData((current) => ({
          ...current,
          workoutEntries: current.workoutEntries.map((entry) => (entry.id === id ? { ...entry, ...patch } : entry)),
        })),
      removeWorkout: (id) =>
        setData((current) => ({ ...current, workoutEntries: current.workoutEntries.filter((entry) => entry.id !== id) })),
      addPlanItem: (entry) =>
        setData((current) => ({
          ...current,
          planItems: [...current.planItems, { ...entry, id: createId(), completed: false }],
        })),
      togglePlanItem: (id) =>
        setData((current) => ({
          ...current,
          planItems: current.planItems.map((entry) =>
            entry.id === id ? { ...entry, completed: !entry.completed } : entry,
          ),
        })),
      removePlanItem: (id) =>
        setData((current) => ({ ...current, planItems: current.planItems.filter((entry) => entry.id !== id) })),
      updateProfile: (patch) =>
        setData((current) => ({ ...current, profile: { ...current.profile, ...patch } })),
      updateTargets: (patch) =>
        setData((current) => ({ ...current, targets: { ...current.targets, ...patch } })),
      setStepTrackingEnabled: (stepTrackingEnabled) =>
        setData((current) => ({ ...current, stepTrackingEnabled })),
      addStepCount: (dateKey, count) =>
        setData((current) => ({
          ...current,
          stepCounts: {
            ...current.stepCounts,
            [dateKey]: (current.stepCounts[dateKey] ?? 0) + Math.max(0, Math.floor(count)),
          },
        })),
      completeOnboarding: () =>
        setData((current) => ({ ...current, hasCompletedOnboarding: true })),
    }),
    [data, ready, storageError, todayKey],
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const state = useContext(AppStateContext);
  if (!state) throw new Error('useAppState must be used within AppStateProvider');
  return state;
}
