import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { AppButton, AppScreen, Card, ChoiceChip, Field, LabelPill, MutedText, SectionTitle } from '@/components/ui';
import { type CalorieEquation, type WeightGoal, useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const goals = ['Build consistent habits', 'Improve nutrition', 'Get stronger', 'Manage weight'];
const experiences = ['New to exercise', 'Returning / occasional', 'Regular routine'];
const routines = ['Track my current routine', 'Help me adapt my routine', 'Create a beginner plan'];
const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const equipmentOptions = ['Bodyweight', 'Dumbbells', 'Resistance bands', 'Gym access'];
const activityOptions = [
  { label: 'Low movement', multiplier: 1.2 },
  { label: 'Lightly active', multiplier: 1.375 },
  { label: 'Moderately active', multiplier: 1.55 },
  { label: 'Very active', multiplier: 1.725 },
];
const calorieEquations: { value: CalorieEquation; label: string }[] = [
  { value: 'range', label: 'Show a range' },
  { value: 'female', label: 'Female equation' },
  { value: 'male', label: 'Male equation' },
];
const weightGoals: { value: WeightGoal; label: string }[] = [
  { value: 'lose', label: 'Lose ~1 lb / week' },
  { value: 'maintain', label: 'Maintain' },
  { value: 'gain', label: 'Gain ~1 lb / week' },
];

function optionalNumber(text: string, decimal = false) {
  if (!text.trim()) return null;
  const number = Number(text);
  if (!Number.isFinite(number) || number < 0) return null;
  return decimal ? number : Math.round(number);
}

function estimateCalories(profile: ReturnType<typeof useAppState>['profile']) {
  const { ageYears, heightFeet, heightInches, weightPounds, activityLevel, calorieEquation, weightGoal } = profile;
  const totalHeightInches = (heightFeet ?? 0) * 12 + (heightInches ?? 0);
  if (!ageYears || !totalHeightInches || !weightPounds || ageYears <= 0 || weightPounds <= 0) return null;
  if (ageYears < 18) return { isMinor: true as const };

  const heightCm = totalHeightInches * 2.54;
  const weightKg = weightPounds / 2.20462;
  const activity = activityOptions.find((item) => item.label === activityLevel)?.multiplier ?? 1.2;
  const equations = calorieEquation === 'range' ? ['female', 'male'] as const : [calorieEquation] as const;
  const adjustment = weightGoal === 'lose' ? -500 : weightGoal === 'gain' ? 500 : 0;
  const targets = equations.map((equation) => {
    const resting = 10 * weightKg + 6.25 * heightCm - 5 * ageYears + (equation === 'female' ? -161 : 5);
    return Math.round(resting * activity + adjustment);
  });
  const maintenance = equations.map((equation) => {
    const resting = 10 * weightKg + 6.25 * heightCm - 5 * ageYears + (equation === 'female' ? -161 : 5);
    return Math.round(resting * activity);
  });
  return {
    isMinor: false as const,
    targetLow: Math.min(...targets),
    targetHigh: Math.max(...targets),
    maintenanceLow: Math.min(...maintenance),
    maintenanceHigh: Math.max(...maintenance),
  };
}

function calorieRange(low: number, high: number) {
  return low === high ? `${low.toLocaleString()} kcal/day` : `${low.toLocaleString()}–${high.toLocaleString()} kcal/day`;
}

function TargetInput({
  label,
  value,
  onChange,
  testID,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  testID: string;
}) {
  return (
    <Field
      label={label}
      value={value > 0 ? String(value) : ''}
      onChangeText={(text) => onChange(text.trim() ? Math.max(0, Number(text) || 0) : 0)}
      keyboardType="number-pad"
      placeholder="Set your target"
      testID={testID}
    />
  );
}

export default function ProfileScreen() {
  const colors = useColors();
  const { profile, targets, updateProfile, updateTargets, storageError } = useAppState();
  const [targetApplied, setTargetApplied] = useState(false);
  const estimate = estimateCalories(profile);

  const toggleArrayItem = (list: string[], item: string, update: (next: string[]) => void) => {
    update(list.includes(item) ? list.filter((value) => value !== item) : [...list, item]);
  };

  const applyEstimatedCalories = () => {
    if (!estimate || estimate.isMinor) return;
    const calories = Math.round((estimate.targetLow + estimate.targetHigh) / 2);
    if (calories < 1200) {
      Alert.alert('Estimate is too low to apply', 'This rough estimate is below 1,200 kcal/day. Please get personalized guidance from a qualified health professional before setting a target.');
      return;
    }
    updateTargets({ calories });
    setTargetApplied(true);
  };

  return (
    <AppScreen eyebrow="YOUR SETUP" title="Make it yours." subtitle="Add only the details that help. Your profile and calorie estimate stay on this device.">
      {storageError ? <Card><MutedText>{storageError}</MutedText></Card> : null}
      <Card>
        <SectionTitle title="Your main goal" />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {goals.map((goal) => <ChoiceChip key={goal} label={goal} selected={profile.goal === goal} onPress={() => updateProfile({ goal })} testID={`chip-goal-${goals.indexOf(goal)}`} />)}
        </View>
      </Card>

      <Card>
        <SectionTitle title="Fitness experience" />
        <MutedText>Use your own description. This is a starting point, not a rating.</MutedText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {experiences.map((experience) => <ChoiceChip key={experience} label={experience} selected={profile.experience === experience} onPress={() => updateProfile({ experience })} testID={`chip-experience-${experiences.indexOf(experience)}`} />)}
        </View>
        <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13, marginTop: 4 }}>What would you like to do with your routine?</Text>
        <View style={{ gap: 8 }}>
          {routines.map((routine) => <ChoiceChip key={routine} label={routine} selected={profile.routineMode === routine} onPress={() => updateProfile({ routineMode: routine })} testID={`chip-routine-${routines.indexOf(routine)}`} />)}
        </View>
      </Card>

      <Card>
        <SectionTitle title="Your time & equipment" />
        <MutedText>Choose days that usually work. It’s fine if your schedule changes.</MutedText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {allDays.map((day) => <ChoiceChip key={day} label={day.slice(0, 3)} selected={profile.daysAvailable.includes(day)} onPress={() => toggleArrayItem(profile.daysAvailable, day, (daysAvailable) => updateProfile({ daysAvailable }))} testID={`chip-availability-${day.toLowerCase()}`} />)}
        </View>
        <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13, marginTop: 4 }}>Equipment you can use</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {equipmentOptions.map((item) => <ChoiceChip key={item} label={item} selected={profile.equipment.includes(item)} onPress={() => toggleArrayItem(profile.equipment, item, (equipment) => updateProfile({ equipment }))} testID={`chip-equipment-${equipmentOptions.indexOf(item)}`} />)}
        </View>
        <Field label="Anything you want a plan to work around? (optional)" value={profile.movementNotes} onChangeText={(movementNotes) => updateProfile({ movementNotes })} placeholder="Share only what you want the app to consider" multiline testID="input-movement-notes" />
      </Card>

      <Card>
        <SectionTitle title="About you" right={<LabelPill>Optional</LabelPill>} />
        <MutedText>These details help estimate daily calories. You can leave any field blank.</MutedText>
        <Field
          label="Age (years)"
          value={profile.ageYears === null ? '' : String(profile.ageYears)}
          onChangeText={(text) => updateProfile({ ageYears: optionalNumber(text) })}
          placeholder="e.g. 30"
          keyboardType="number-pad"
          testID="input-profile-age"
        />
        <View style={{ flexDirection: 'row', gap: 9 }}>
          <View style={{ flex: 1 }}>
            <Field
              label="Height (feet)"
              value={profile.heightFeet === null ? '' : String(profile.heightFeet)}
              onChangeText={(text) => updateProfile({ heightFeet: optionalNumber(text) })}
              placeholder="e.g. 5"
              keyboardType="number-pad"
              testID="input-profile-height-feet"
            />
          </View>
          <View style={{ flex: 1 }}>
            <Field
              label="Extra inches"
              value={profile.heightInches === null ? '' : String(profile.heightInches)}
              onChangeText={(text) => updateProfile({ heightInches: optionalNumber(text) === null ? null : Math.min(11, optionalNumber(text) ?? 0) })}
              placeholder="0–11"
              keyboardType="number-pad"
              testID="input-profile-height-inches"
            />
          </View>
          <View style={{ flex: 1.25 }}>
            <Field
              label="Weight (lb)"
              value={profile.weightPounds === null ? '' : String(profile.weightPounds)}
              onChangeText={(text) => updateProfile({ weightPounds: optionalNumber(text, true) })}
              placeholder="e.g. 160"
              keyboardType="decimal-pad"
              testID="input-profile-weight"
            />
          </View>
        </View>
      </Card>

      <Card>
        <SectionTitle title="Calorie estimate" right={<LabelPill>Estimate only</LabelPill>} />
        <MutedText>Choose your activity and direction. Losing or gaining about 1 lb per week uses an approximate 500 kcal/day adjustment. This is a starting estimate, not medical advice.</MutedText>
        <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>Typical activity level</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {activityOptions.map((item) => (
            <ChoiceChip
              key={item.label}
              label={item.label}
              selected={profile.activityLevel === item.label}
              onPress={() => { updateProfile({ activityLevel: item.label }); setTargetApplied(false); }}
              testID={`chip-activity-${item.label.toLowerCase().replaceAll(' ', '-')}`}
            />
          ))}
        </View>
        <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>Your goal</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {weightGoals.map((item) => (
            <ChoiceChip
              key={item.value}
              label={item.label}
              selected={profile.weightGoal === item.value}
              onPress={() => { updateProfile({ weightGoal: item.value }); setTargetApplied(false); }}
              testID={`chip-weight-goal-${item.value}`}
            />
          ))}
        </View>
        <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>Calculation preference</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {calorieEquations.map((item) => (
            <ChoiceChip
              key={item.value}
              label={item.label}
              selected={profile.calorieEquation === item.value}
              onPress={() => { updateProfile({ calorieEquation: item.value }); setTargetApplied(false); }}
              testID={`chip-calorie-equation-${item.value}`}
            />
          ))}
        </View>
        <MutedText>The two equations use different standard constants. “Show a range” avoids choosing one and applies the midpoint if you accept it.</MutedText>
        {!estimate ? (
          <MutedText>Add age, height, and weight to see an estimate.</MutedText>
        ) : estimate.isMinor ? (
          <MutedText>Calorie targets are not estimated for people under 18. Please get guidance from a pediatric health professional.</MutedText>
        ) : (
          <View style={{ backgroundColor: colors.secondary, borderRadius: colors.radius, padding: 14, gap: 6 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>
              Suggested target: {calorieRange(estimate.targetLow, estimate.targetHigh)}
            </Text>
            <MutedText>Estimated maintenance: {calorieRange(estimate.maintenanceLow, estimate.maintenanceHigh)}</MutedText>
            {estimate.targetLow < 1200 ? <MutedText>This estimate falls below 1,200 kcal/day. It won’t be applied automatically; ask a qualified health professional for guidance.</MutedText> : null}
            <AppButton
              label={targetApplied && targets.calories === Math.round((estimate.targetLow + estimate.targetHigh) / 2) ? 'Target applied' : 'Use this calorie target'}
              icon="check"
              onPress={applyEstimatedCalories}
              disabled={estimate.targetLow < 1200}
              testID="button-apply-calorie-estimate"
            />
          </View>
        )}
      </Card>

      <Card>
        <SectionTitle title="Nutrition targets" right={<LabelPill>User-set</LabelPill>} />
        <MutedText>Calories can be set here or filled from the estimate above. Macros stay user-set. Targets are saved on this device.</MutedText>
        <TargetInput label="Calories (kcal)" value={targets.calories} onChange={(calories) => updateTargets({ calories })} testID="input-target-calories" />
        <View style={{ flexDirection: 'row', gap: 9 }}>
          <View style={{ flex: 1 }}><TargetInput label="Protein (g)" value={targets.protein} onChange={(protein) => updateTargets({ protein })} testID="input-target-protein" /></View>
          <View style={{ flex: 1 }}><TargetInput label="Carbs (g)" value={targets.carbs} onChange={(carbs) => updateTargets({ carbs })} testID="input-target-carbs" /></View>
        </View>
        <TargetInput label="Fat (g)" value={targets.fat} onChange={(fat) => updateTargets({ fat })} testID="input-target-fat" />
      </Card>

      <Card style={{ backgroundColor: colors.secondary, borderColor: colors.secondary }}>
        <SectionTitle title="A note on your data" />
        <MutedText>This draft saves your logs and setup on this device. Mobile and web data do not sync yet. Step count uses the device pedometer; Apple Health/Watch history import is not connected.</MutedText>
      </Card>
    </AppScreen>
  );
}
