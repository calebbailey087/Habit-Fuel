import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Linking, Platform, Text, View } from 'react-native';
import { AppButton, AppScreen, Card, LabelPill, MutedText, ProgressBar, SectionTitle } from '@/components/ui';
import { useAppState } from '@/context/AppState';
import { useDailySteps } from '@/hooks/useDailySteps';
import { useColors } from '@/hooks/useColors';

export default function TodayScreen() {
  const colors = useColors();
  const { foodEntries, workoutEntries, planItems, targets, storageError, todayKey } = useAppState();
  const { steps, status, enable, disable, refresh } = useDailySteps();
  const todayFoodEntries = foodEntries.filter((entry) => entry.dateKey === todayKey);
  const todayWorkoutEntries = workoutEntries.filter((entry) => entry.dateKey === todayKey);
  const calories = todayFoodEntries.reduce((sum, entry) => sum + entry.calories, 0);
  const protein = todayFoodEntries.reduce((sum, entry) => sum + entry.protein, 0);
  const carbs = todayFoodEntries.reduce((sum, entry) => sum + entry.carbs, 0);
  const fat = todayFoodEntries.reduce((sum, entry) => sum + entry.fat, 0);
  const burn = todayWorkoutEntries.reduce((sum, entry) => sum + entry.caloriesBurnedEstimate, 0);
  const nextPlan = planItems.find((item) => !item.completed);
  const dateLabel = new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date());

  return (
    <AppScreen
      eyebrow={dateLabel.toUpperCase()}
      title="A good day, at your pace."
      subtitle="A little awareness goes a long way. Here’s where today is at."
    >
      {storageError ? <Card><MutedText>{storageError}</MutedText></Card> : null}

      <Card style={{ backgroundColor: colors.primary, borderColor: colors.primary, padding: 20 }}>
        <Text style={{ color: colors.primaryForeground, fontFamily: 'DMSans_700Bold', fontSize: 11, letterSpacing: 1.4 }}>ONE DAY AT A TIME</Text>
        <Text style={{ color: colors.primaryForeground, fontFamily: 'DMSans_600SemiBold', fontSize: 22, lineHeight: 28 }}>
          You’re building a day that works for you.
        </Text>
        <Text style={{ color: colors.primaryForeground, opacity: 0.84, fontSize: 14, lineHeight: 21, fontFamily: 'DMSans_400Regular' }}>
          Use your log as a guide, not a grade. Small, repeatable choices count.
        </Text>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 4 }}>
          <View style={{ flex: 1 }}><AppButton label="Log a meal" icon="plus" tone="soft" onPress={() => router.navigate('/log')} testID="button-home-log-meal" /></View>
          <View style={{ flex: 1 }}><AppButton label="See your plan" icon="activity" tone="soft" onPress={() => router.navigate('/plan')} testID="button-home-plan" /></View>
        </View>
      </Card>

      <Card>
        <SectionTitle title="Food so far" right={<LabelPill>From your log</LabelPill>} />
        <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 7 }}>
          <Text testID="text-home-calories" style={{ color: colors.foreground, fontSize: 34, fontFamily: 'DMSans_700Bold' }}>{calories.toLocaleString()}</Text>
          <MutedText>of {targets.calories.toLocaleString()} kcal</MutedText>
        </View>
        {[
          { name: 'Protein', value: protein, max: targets.protein, color: colors.accent },
          { name: 'Carbs', value: carbs, max: targets.carbs, color: '#c6a44a' },
          { name: 'Fat', value: fat, max: targets.fat, color: '#78998e' },
        ].map((macro) => (
          <View key={macro.name} style={{ gap: 6 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: colors.foreground, fontSize: 13, fontFamily: 'DMSans_600SemiBold' }}>{macro.name}</Text>
              <MutedText>{macro.value} / {macro.max} g</MutedText>
            </View>
            <ProgressBar value={macro.value} max={macro.max} color={macro.color} />
          </View>
        ))}
        <AppButton label="Open food log" icon="arrow-right" tone="outline" onPress={() => router.navigate('/log')} testID="button-home-food-log" />
      </Card>

      <Card style={{ backgroundColor: colors.secondary, borderColor: colors.secondary }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 42, height: 42, borderRadius: 15, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' }}>
            <Feather name="activity" size={20} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 17 }}>Movement</Text>
            <MutedText>Kept separate from your food totals</MutedText>
          </View>
          <Text style={{ color: colors.foreground, fontSize: 22, fontFamily: 'DMSans_700Bold' }}>~{burn}</Text>
        </View>
        <MutedText>Estimated kcal burn. It’s a rough estimate and isn’t subtracted from your food target.</MutedText>
        <AppButton label="Log movement" icon="plus" tone="soft" onPress={() => router.navigate('/log')} testID="button-home-log-movement" />
      </Card>

      <Card>
        <SectionTitle title="Steps today" right={<Feather name="navigation" size={18} color={colors.primary} />} />
        {status === 'connected' ? (
          <>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 34 }}>
              {(steps ?? 0).toLocaleString()}
            </Text>
            <MutedText>
              {Platform.OS === 'android'
                ? 'Counted by this device while Habit Fuel is open. Background tracking and Health Connect sync are not included yet.'
                : 'Today’s count comes from the iPhone’s pedometer. It stays on this device; Apple Health/Watch history is not imported.'}
            </MutedText>
            <View style={{ flexDirection: 'row', gap: 9 }}>
              <View style={{ flex: 1 }}><AppButton label="Refresh steps" icon="refresh-cw" tone="outline" onPress={() => void refresh()} testID="button-refresh-steps" /></View>
              <View style={{ flex: 1 }}><AppButton label="Turn off" tone="outline" onPress={disable} testID="button-disable-steps" /></View>
            </View>
          </>
        ) : status === 'loading' ? (
          <MutedText>Checking step-count permission and device support…</MutedText>
        ) : status === 'unsupported' ? (
          <MutedText>Step counting is available on a supported iOS or Android device, not in this web preview.</MutedText>
        ) : status === 'permission-denied' || status === 'error' ? (
          <>
            <MutedText>Step access is unavailable. Check your device’s motion permission, then try again.</MutedText>
            <View style={{ flexDirection: 'row', gap: 9 }}>
              <View style={{ flex: 1 }}><AppButton label="Try again" icon="refresh-cw" onPress={() => void enable()} testID="button-retry-steps" /></View>
              {Platform.OS !== 'web' ? <View style={{ flex: 1 }}><AppButton label="Open settings" tone="outline" onPress={() => void Linking.openSettings()} testID="button-open-step-settings" /></View> : null}
            </View>
          </>
        ) : (
          <>
            <MutedText>Use your phone’s built-in step counter. Habit Fuel asks before reading it and keeps the count on this device. On Android, steps are counted while the app is open.</MutedText>
            <AppButton label="Enable step count" icon="activity" onPress={() => void enable()} testID="button-enable-steps" />
          </>
        )}
      </Card>

      <Card>
        <SectionTitle title="Next on your plan" right={<Feather name="calendar" size={18} color={colors.mutedForeground} />} />
        {nextPlan ? (
          <>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <View style={{ width: 42, height: 42, borderRadius: 15, backgroundColor: colors.secondary, alignItems: 'center', justifyContent: 'center' }}>
                <Feather name="activity" size={19} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>{nextPlan.name}</Text>
                <MutedText>{nextPlan.day} · {nextPlan.durationMinutes} min</MutedText>
              </View>
            </View>
            <AppButton label="View your plan" icon="arrow-right" tone="outline" onPress={() => router.navigate('/plan')} testID="button-home-view-plan" />
          </>
        ) : (
          <MutedText>Your plan is clear for now. Add a session whenever it fits.</MutedText>
        )}
      </Card>

      <Card>
        <SectionTitle title="Today’s log" right={<LabelPill>{todayFoodEntries.length + todayWorkoutEntries.length} entries</LabelPill>} />
        {todayFoodEntries.slice(0, 3).map((entry) => (
          <View key={entry.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 7 }}>
            <View style={{ width: 36, height: 36, borderRadius: 13, backgroundColor: colors.secondary, alignItems: 'center', justifyContent: 'center' }}>
              <Feather name="coffee" size={16} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 14 }}>{entry.name}</Text>
              <MutedText>{entry.meal} · {entry.time}</MutedText>
            </View>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>{entry.calories} kcal</Text>
          </View>
        ))}
      </Card>
    </AppScreen>
  );
}
