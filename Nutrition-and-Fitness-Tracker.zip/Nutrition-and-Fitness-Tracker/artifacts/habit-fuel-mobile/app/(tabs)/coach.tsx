import { Feather } from '@expo/vector-icons';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { AppButton, AppScreen, Card, ChoiceChip, MutedText, SectionTitle } from '@/components/ui';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const prompts = ['How did today go?', 'What could I focus on next?', 'Show me a nutrition pattern'];

export default function CoachScreen() {
  const colors = useColors();
  const { foodEntries, workoutEntries, targets, planItems } = useAppState();
  const [selectedPrompt, setSelectedPrompt] = useState<string | null>(null);
  const calories = foodEntries.reduce((sum, item) => sum + item.calories, 0);
  const protein = foodEntries.reduce((sum, item) => sum + item.protein, 0);
  const completed = planItems.filter((item) => item.completed).length;

  const response = selectedPrompt === 'How did today go?'
    ? `You have ${foodEntries.length} food entries and ${workoutEntries.length} movement ${workoutEntries.length === 1 ? 'entry' : 'entries'} in your log. That is what this check-in can see; it may not represent your whole day.`
    : selectedPrompt === 'What could I focus on next?'
      ? workoutEntries.length > 0
        ? 'You have already logged movement. A useful next step could be choosing a day for your next planned session, or taking a rest day if that fits how you feel.'
        : 'A short, easy movement session is one option. You can also start by logging a meal—small steps are enough to begin.'
      : `Based on ${foodEntries.length} logged food ${foodEntries.length === 1 ? 'entry' : 'entries'}, you have ${protein} g protein and ${calories.toLocaleString()} kcal recorded. Your chosen protein target is ${targets.protein} g.`;

  return (
    <AppScreen eyebrow="WHEN YOU ASK" title="A coach in your corner." subtitle="Thoughtful notes from your own logs, without pressure or surprise nudges.">
      <Card style={{ backgroundColor: colors.secondary, borderColor: colors.secondary }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11 }}>
          <View style={{ width: 42, height: 42, borderRadius: 15, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' }}>
            <Feather name="sun" size={19} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 16 }}>Your coach is on demand</Text>
            <MutedText>No daily prompts. Open this tab when you want a reflection.</MutedText>
          </View>
        </View>
      </Card>

      <Card>
        <SectionTitle title="What would you like to explore?" />
        <View style={{ gap: 9 }}>
          {prompts.map((prompt) => (
            <ChoiceChip key={prompt} label={prompt} selected={selectedPrompt === prompt} onPress={() => setSelectedPrompt(prompt)} testID={`chip-coach-${prompts.indexOf(prompt)}`} />
          ))}
        </View>
        <AppButton label="Get a reflection" icon="message-circle" onPress={() => setSelectedPrompt(selectedPrompt ?? prompts[0])} testID="button-coach-reflection" />
      </Card>

      {selectedPrompt ? (
        <Card testID="card-coach-response">
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Feather name="star" size={17} color={colors.accent} />
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>A draft reflection</Text>
          </View>
          <Text style={{ color: colors.foreground, fontFamily: 'DMSans_400Regular', fontSize: 15, lineHeight: 23 }}>{response}</Text>
          <MutedText>Based on your visible app entries. This is a sample coach experience, not live AI or health advice. Estimates and incomplete logs can be inaccurate.</MutedText>
        </Card>
      ) : null}

      <Card>
        <SectionTitle title="Your recent pattern" />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 23 }}>{foodEntries.length}</Text>
            <MutedText>food entries</MutedText>
          </View>
          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 23 }}>{workoutEntries.length}</Text>
            <MutedText>movement logs</MutedText>
          </View>
          <View style={{ gap: 4 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 23 }}>{completed}</Text>
            <MutedText>planned sessions done</MutedText>
          </View>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Feather name="info" size={15} color={colors.mutedForeground} />
          <MutedText>More days of logging help reveal patterns; missed entries are not treated as zero.</MutedText>
        </View>
      </Card>
    </AppScreen>
  );
}
