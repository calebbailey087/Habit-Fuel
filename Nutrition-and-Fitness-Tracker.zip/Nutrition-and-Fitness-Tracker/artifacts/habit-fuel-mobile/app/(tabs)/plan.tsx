import { Feather } from '@expo/vector-icons';
import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { AppButton, AppScreen, Card, ChoiceChip, Field, IconButton, LabelPill, MutedText, SectionTitle } from '@/components/ui';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function PlanScreen() {
  const colors = useColors();
  const { planItems, addPlanItem, togglePlanItem, removePlanItem, profile } = useAppState();
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  const [day, setDay] = useState(profile.daysAvailable[0] ?? 'Monday');
  const [duration, setDuration] = useState('30');
  const completed = planItems.filter((item) => item.completed).length;

  const savePlanItem = () => {
    if (!name.trim() || Number(duration) <= 0) {
      Alert.alert('Add a session name and duration.');
      return;
    }
    addPlanItem({ name: name.trim(), day, durationMinutes: Math.round(Number(duration)) });
    setName('');
    setDuration('30');
    setAdding(false);
  };

  return (
    <AppScreen eyebrow="YOUR ROUTINE, YOUR PACE" title="A plan that can flex." subtitle="Keep the routine you know, or shape a simple week around the time you have.">
      <Card style={{ backgroundColor: colors.primary, borderColor: colors.primary }}>
        <Text style={{ color: colors.primaryForeground, fontFamily: 'DMSans_700Bold', fontSize: 11, letterSpacing: 1.4 }}>THIS WEEK</Text>
        <Text style={{ color: colors.primaryForeground, fontFamily: 'DMSans_700Bold', fontSize: 25 }}>{completed} of {planItems.length} sessions checked off</Text>
        <MutedText style={{ color: colors.primaryForeground, opacity: 0.82 }}>A plan is a guide, not a pass/fail test. Adjust it whenever life changes.</MutedText>
      </Card>

      <Card>
        <SectionTitle title="Your weekly plan" right={<LabelPill>{profile.experience}</LabelPill>} />
        {planItems.length === 0 ? <MutedText>No sessions planned yet. Add something that feels manageable.</MutedText> : planItems.map((item) => (
          <View key={item.id} testID={`row-plan-${item.id}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 11, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 13 }}>
            <View style={{ width: 40, height: 40, borderRadius: 14, backgroundColor: item.completed ? colors.primary : colors.secondary, alignItems: 'center', justifyContent: 'center' }}>
              <Feather name={item.completed ? 'check' : 'activity'} size={18} color={item.completed ? colors.primaryForeground : colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>{item.name}</Text>
              <MutedText>{item.day} · {item.durationMinutes} min</MutedText>
            </View>
            <IconButton icon={item.completed ? 'rotate-ccw' : 'check'} label={item.completed ? 'Mark session incomplete' : 'Mark session complete'} onPress={() => togglePlanItem(item.id)} testID={`button-toggle-plan-${item.id}`} />
            <IconButton icon="trash-2" label={`Remove ${item.name}`} destructive onPress={() => removePlanItem(item.id)} testID={`button-delete-plan-${item.id}`} />
          </View>
        ))}
        <AppButton label={adding ? 'Close session form' : 'Add a session'} icon={adding ? 'x' : 'plus'} tone="outline" onPress={() => setAdding(!adding)} testID="button-toggle-add-plan" />
      </Card>

      {adding ? (
        <Card>
          <SectionTitle title="Make this plan yours" />
          <Field label="Session" value={name} onChangeText={setName} placeholder="e.g. Easy walk" testID="input-plan-name" />
          <View style={{ gap: 8 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>Day</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {days.map((item) => <ChoiceChip key={item} label={item.slice(0, 3)} selected={day === item} onPress={() => setDay(item)} testID={`chip-plan-day-${item.toLowerCase()}`} />)}
            </View>
          </View>
          <Field label="Time (minutes)" value={duration} onChangeText={setDuration} keyboardType="number-pad" placeholder="30" testID="input-plan-duration" />
          <AppButton label="Save session" icon="check" onPress={savePlanItem} testID="button-save-plan" />
        </Card>
      ) : null}

      <Card>
        <SectionTitle title="Built around your setup" />
        <MutedText>Goal: {profile.goal}</MutedText>
        <MutedText>Experience: {profile.experience}</MutedText>
        <MutedText>Available: {profile.daysAvailable.length ? profile.daysAvailable.join(', ') : 'Choose days in Setup'}</MutedText>
        <MutedText>Equipment: {profile.equipment.length ? profile.equipment.join(', ') : 'No equipment selected'}</MutedText>
        <AppButton label="Adjust your setup" icon="sliders" tone="soft" onPress={() => Alert.alert('Your setup', 'Use the Setup tab to update your experience, schedule, equipment, and goals.')} testID="button-plan-setup-hint" />
      </Card>
    </AppScreen>
  );
}
