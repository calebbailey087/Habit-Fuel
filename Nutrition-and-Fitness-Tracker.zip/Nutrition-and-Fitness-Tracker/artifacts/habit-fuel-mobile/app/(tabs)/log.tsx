import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Image, Linking, Platform, Text, View } from 'react-native';
import { useState } from 'react';
import { AppButton, AppScreen, Card, ChoiceChip, Field, IconButton, LabelPill, MutedText, SectionTitle } from '@/components/ui';
import { type Effort, type ExerciseSet, type FoodEntry, type FoodSource, type WorkoutEntry, useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

interface ExerciseDraft {
  key: string;
  name: string;
  sets: string;
  reps: string;
  weight: string;
}

function createExerciseDraft(exercise?: ExerciseSet): ExerciseDraft {
  return {
    key: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
    name: exercise?.name ?? '',
    sets: exercise ? String(exercise.sets) : '',
    reps: exercise ? String(exercise.reps) : '',
    weight: exercise && exercise.weight > 0 ? String(exercise.weight) : '',
  };
}

const sourceLabel: Record<FoodSource, string> = {
  manual: 'Manual entry',
  'meal-photo': 'Meal photo · estimate not connected',
  'label-photo': 'Label photo · scanning not connected',
};

function asNumber(value: string) {
  if (!value.trim()) return 0;
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, number) : 0;
}

function dateLabel(dateKey: string) {
  const [year, month, day] = dateKey.split('-').map(Number);
  return new Date(year, month - 1, day).toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export default function LogScreen() {
  const colors = useColors();
  const {
    foodEntries,
    foodPresets,
    workoutEntries,
    addFood,
    updateFood,
    removeFood,
    addFoodPreset,
    addFoodFromPreset,
    removeFoodPreset,
    addWorkout,
    updateWorkout,
    removeWorkout,
    todayKey,
  } = useAppState();
  const [foodOpen, setFoodOpen] = useState(false);
  const [workoutOpen, setWorkoutOpen] = useState(false);
  const [foodEditId, setFoodEditId] = useState<string | null>(null);
  const [workoutEditId, setWorkoutEditId] = useState<string | null>(null);
  const [foodName, setFoodName] = useState('');
  const [meal, setMeal] = useState('Meal');
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');
  const [foodSource, setFoodSource] = useState<FoodSource>('manual');
  const [photoPurpose, setPhotoPurpose] = useState<'meal-photo' | 'label-photo'>('meal-photo');
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [workoutName, setWorkoutName] = useState('');
  const [duration, setDuration] = useState('');
  const [effort, setEffort] = useState<Effort>('Moderate');
  const [exercises, setExercises] = useState<ExerciseDraft[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [cameraPermission, requestCameraPermission] = ImagePicker.useCameraPermissions();
  const [mediaPermission, requestMediaPermission] = ImagePicker.useMediaLibraryPermissions();

  const resetFood = () => {
    setFoodName('');
    setMeal('Meal');
    setCalories('');
    setProtein('');
    setCarbs('');
    setFat('');
    setFoodSource('manual');
    setPhotoUri(null);
    setFoodEditId(null);
    setFoodOpen(false);
  };

  const editFood = (entry: FoodEntry) => {
    setFoodEditId(entry.id);
    setFoodName(entry.name);
    setMeal(entry.meal);
    setCalories(String(entry.calories));
    setProtein(String(entry.protein));
    setCarbs(String(entry.carbs));
    setFat(String(entry.fat));
    setFoodSource(entry.source);
    setPhotoUri(null);
    setFoodOpen(true);
    setWorkoutOpen(false);
  };

  const openDevicePhoto = async (useCamera: boolean) => {
    const permission = useCamera ? cameraPermission : mediaPermission;
    const requestPermission = useCamera ? requestCameraPermission : requestMediaPermission;
    const result = permission?.granted ? permission : await requestPermission();
    if (!result.granted) {
      const message = useCamera ? 'Allow camera access to take a food photo.' : 'Allow photo access to choose a food image.';
      if (result.canAskAgain) {
        Alert.alert('Permission needed', message);
      } else {
        Alert.alert('Permission needed', message, [
          { text: 'Not now', style: 'cancel' },
          { text: 'Open settings', onPress: () => { if (Platform.OS !== 'web') void Linking.openSettings(); } },
        ]);
      }
      return;
    }
    const picked = useCamera
      ? await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 })
      : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 });
    if (picked.canceled || !picked.assets[0]) return;
    setPhotoUri(picked.assets[0].uri);
    setFoodSource(photoPurpose);
    if (!foodName) setFoodName(photoPurpose === 'meal-photo' ? 'Meal photo estimate' : 'Nutrition label entry');
  };

  const saveFood = () => {
    if (!foodName.trim() || asNumber(calories) <= 0) {
      Alert.alert('Add the basics first', 'Enter a food name and calorie amount to save this entry.');
      return;
    }
    const entry = {
      name: foodName.trim(),
      meal,
      time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
      calories: asNumber(calories),
      protein: asNumber(protein),
      carbs: asNumber(carbs),
      fat: asNumber(fat),
      source: foodSource,
    };
    if (foodEditId) updateFood(foodEditId, entry);
    else addFood(entry);
    resetFood();
  };

  const resetWorkout = () => {
    setWorkoutName('');
    setDuration('');
    setEffort('Moderate');
    setExercises([]);
    setWorkoutEditId(null);
    setWorkoutOpen(false);
  };

  const editWorkout = (entry: WorkoutEntry) => {
    setWorkoutEditId(entry.id);
    setWorkoutName(entry.name);
    setDuration(String(entry.durationMinutes));
    setEffort(entry.effort);
    setExercises(entry.exercises.map(createExerciseDraft));
    setWorkoutOpen(true);
    setFoodOpen(false);
  };

  const burnFor = (minutes: number) =>
    Math.round(minutes * (effort === 'Easy' ? 3.2 : effort === 'Hard' ? 7.2 : 5.2));

  const saveWorkout = () => {
    const minutes = asNumber(duration);
    if (!workoutName.trim() || minutes <= 0) {
      Alert.alert('Add the basics first', 'Enter an activity and duration to save this workout.');
      return;
    }
    const savedExercises = exercises
      .filter((exercise) => exercise.name.trim())
      .map((exercise) => ({
        name: exercise.name.trim(),
        sets: asNumber(exercise.sets),
        reps: asNumber(exercise.reps),
        weight: asNumber(exercise.weight),
      }));
    const entry = {
      name: workoutName.trim(),
      type: workoutName.trim(),
      durationMinutes: minutes,
      effort,
      caloriesBurnedEstimate: burnFor(minutes),
      exercises: savedExercises,
    };
    if (workoutEditId) updateWorkout(workoutEditId, entry);
    else addWorkout(entry);
    resetWorkout();
  };

  const confirmDeleteFood = (entry: FoodEntry) =>
    Alert.alert('Remove food entry?', entry.name, [
      { text: 'Keep it', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => removeFood(entry.id) },
    ]);

  const confirmDeleteWorkout = (entry: WorkoutEntry) =>
    Alert.alert('Remove workout?', entry.name, [
      { text: 'Keep it', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => removeWorkout(entry.id) },
    ]);

  const savePreset = (entry: FoodEntry) => {
    const alreadySaved = foodPresets.some(
      (preset) => preset.name.trim().toLowerCase() === entry.name.trim().toLowerCase() && preset.meal === entry.meal,
    );
    if (alreadySaved) return;
    const { id: _id, dateKey: _dateKey, time: _time, ...preset } = entry;
    addFoodPreset(preset);
  };

  const todayFoodEntries = foodEntries.filter((entry) => entry.dateKey === todayKey);
  const pastFoodEntries = foodEntries.filter((entry) => entry.dateKey !== todayKey);
  const todayWorkoutEntries = workoutEntries.filter((entry) => entry.dateKey === todayKey);
  const pastWorkoutEntries = workoutEntries.filter((entry) => entry.dateKey !== todayKey);
  const pastEntryCount = pastFoodEntries.length + pastWorkoutEntries.length;

  return (
    <AppScreen eyebrow="YOUR DAILY LOG" title="Food & movement" subtitle="Today’s list starts fresh at local midnight. Earlier entries stay in history.">
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}>
          <AppButton label="Add food" icon="plus" onPress={() => { setFoodOpen(!foodOpen); setWorkoutOpen(false); }} testID="button-open-food-form" />
        </View>
        <View style={{ flex: 1 }}>
          <AppButton label="Add workout" icon="activity" tone="soft" onPress={() => { setWorkoutOpen(!workoutOpen); setFoodOpen(false); }} testID="button-open-workout-form" />
        </View>
      </View>

      <Card>
        <SectionTitle title="Quick-add meals" right={<LabelPill>{foodPresets.length} saved</LabelPill>} />
        {foodPresets.length === 0 ? (
          <MutedText>Save a meal from today’s log and it will be ready to add here next time.</MutedText>
        ) : foodPresets.map((preset) => (
          <View key={preset.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 14 }}>{preset.name}</Text>
              <MutedText>{preset.meal} · {preset.calories} kcal · {preset.protein} g protein</MutedText>
            </View>
            <AppButton label="Add" icon="plus" tone="soft" onPress={() => addFoodFromPreset(preset.id)} testID={`button-quick-add-food-${preset.id}`} />
            <IconButton icon="trash-2" label={`Delete ${preset.name} preset`} onPress={() => removeFoodPreset(preset.id)} destructive testID={`button-delete-food-preset-${preset.id}`} />
          </View>
        ))}
      </Card>

      {foodOpen ? (
        <Card>
          <SectionTitle title={foodEditId ? 'Edit food entry' : 'Add food'} />
          <MutedText>Calories and macros are yours to confirm. Photo analysis is not connected in this draft.</MutedText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {(['manual', 'meal-photo', 'label-photo'] as FoodSource[]).map((item) => (
              <ChoiceChip key={item} label={item === 'manual' ? 'Type it in' : item === 'meal-photo' ? 'Meal photo' : 'Label photo'} selected={foodSource === item || (foodSource === 'manual' && photoPurpose === item)} onPress={() => {
                if (item === 'manual') {
                  setFoodSource('manual');
                  setPhotoUri(null);
                } else {
                  setPhotoPurpose(item);
                  setFoodSource(item);
                }
              }} testID={`chip-food-source-${item}`} />
            ))}
          </View>
          {foodSource !== 'manual' ? (
            <View style={{ gap: 10 }}>
              <MutedText>{foodSource === 'meal-photo' ? 'Take or choose a meal photo, then enter your own approximate values. This version does not analyze the image.' : 'Take or choose a label photo, then enter the values shown on the package. Label scanning is not connected yet.'}</MutedText>
              <View style={{ flexDirection: 'row', gap: 9 }}>
                <View style={{ flex: 1 }}><AppButton label="Take photo" icon="camera" tone="outline" onPress={() => void openDevicePhoto(true)} testID="button-food-camera" /></View>
                <View style={{ flex: 1 }}><AppButton label="Choose photo" icon="image" tone="outline" onPress={() => void openDevicePhoto(false)} testID="button-food-gallery" /></View>
              </View>
              {photoUri ? <Image source={{ uri: photoUri }} accessibilityLabel="Selected food photo" style={{ height: 170, width: '100%', borderRadius: 16, backgroundColor: colors.secondary }} resizeMode="cover" /> : null}
            </View>
          ) : null}
          <Field label="Food or drink" value={foodName} onChangeText={setFoodName} placeholder="e.g. yogurt and berries" testID="input-food-name" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {['Breakfast', 'Lunch', 'Dinner', 'Snack'].map((item) => (
              <ChoiceChip key={item} label={item} selected={meal === item} onPress={() => setMeal(item)} testID={`chip-meal-${item.toLowerCase()}`} />
            ))}
          </View>
          <View style={{ flexDirection: 'row', gap: 9 }}>
            <View style={{ flex: 1 }}><Field label="Calories" value={calories} onChangeText={setCalories} keyboardType="decimal-pad" placeholder="0" testID="input-food-calories" /></View>
            <View style={{ flex: 1 }}><Field label="Protein (g)" value={protein} onChangeText={setProtein} keyboardType="decimal-pad" placeholder="0" testID="input-food-protein" /></View>
          </View>
          <View style={{ flexDirection: 'row', gap: 9 }}>
            <View style={{ flex: 1 }}><Field label="Carbs (g)" value={carbs} onChangeText={setCarbs} keyboardType="decimal-pad" placeholder="0" testID="input-food-carbs" /></View>
            <View style={{ flex: 1 }}><Field label="Fat (g)" value={fat} onChangeText={setFat} keyboardType="decimal-pad" placeholder="0" testID="input-food-fat" /></View>
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><AppButton label={foodEditId ? 'Save changes' : 'Add to log'} icon="check" onPress={saveFood} testID="button-save-food" /></View>
            <View style={{ flex: 1 }}><AppButton label="Cancel" tone="outline" onPress={resetFood} testID="button-cancel-food" /></View>
          </View>
        </Card>
      ) : null}

      {workoutOpen ? (
        <Card>
          <SectionTitle title={workoutEditId ? 'Edit workout' : 'Log a workout'} />
          <Field label="Activity" value={workoutName} onChangeText={setWorkoutName} placeholder="e.g. Strength training or a walk" testID="input-workout-name" />
          <Field label="Duration (minutes)" value={duration} onChangeText={setDuration} keyboardType="number-pad" placeholder="30" testID="input-workout-duration" />
          <View style={{ gap: 8 }}>
            <Text style={{ color: colors.foreground, fontFamily: 'DMSans_600SemiBold', fontSize: 13 }}>Effort</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {(['Easy', 'Moderate', 'Hard'] as Effort[]).map((item) => (
                <ChoiceChip key={item} label={item} selected={effort === item} onPress={() => setEffort(item)} testID={`chip-effort-${item.toLowerCase()}`} />
              ))}
            </View>
          </View>
          <View style={{ gap: 8 }}>
            <SectionTitle title="Exercises" right={<LabelPill>Optional · {exercises.length}</LabelPill>} />
            {exercises.map((exercise, index) => (
              <View key={exercise.key} style={{ gap: 9, borderWidth: 1, borderColor: colors.border, borderRadius: colors.radius, padding: 12 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 13 }}>Exercise {index + 1}</Text>
                  <IconButton
                    icon="x"
                    label={`Remove exercise ${index + 1}`}
                    onPress={() => setExercises((current) => current.filter((item) => item.key !== exercise.key))}
                    testID={`button-remove-exercise-${index}`}
                  />
                </View>
                <Field
                  label="Exercise"
                  value={exercise.name}
                  onChangeText={(name) => setExercises((current) => current.map((item) => item.key === exercise.key ? { ...item, name } : item))}
                  placeholder="e.g. Goblet squat"
                  testID={`input-exercise-name-${index}`}
                />
                <View style={{ flexDirection: 'row', gap: 9 }}>
                  <View style={{ flex: 1 }}><Field label="Sets" value={exercise.sets} onChangeText={(sets) => setExercises((current) => current.map((item) => item.key === exercise.key ? { ...item, sets } : item))} keyboardType="number-pad" placeholder="3" testID={`input-exercise-sets-${index}`} /></View>
                  <View style={{ flex: 1 }}><Field label="Reps" value={exercise.reps} onChangeText={(reps) => setExercises((current) => current.map((item) => item.key === exercise.key ? { ...item, reps } : item))} keyboardType="number-pad" placeholder="10" testID={`input-exercise-reps-${index}`} /></View>
                  <View style={{ flex: 1 }}><Field label="Weight (lb)" value={exercise.weight} onChangeText={(weight) => setExercises((current) => current.map((item) => item.key === exercise.key ? { ...item, weight } : item))} keyboardType="decimal-pad" placeholder="Optional" testID={`input-exercise-weight-${index}`} /></View>
                </View>
              </View>
            ))}
            <AppButton
              label="Add another exercise"
              icon="plus"
              tone="outline"
              onPress={() => setExercises((current) => [...current, createExerciseDraft()])}
              testID="button-add-exercise"
            />
          </View>
          <View style={{ backgroundColor: colors.secondary, borderRadius: colors.radius, padding: 12 }}>
            <MutedText>Very rough demo burn estimate: ~{burnFor(asNumber(duration))} kcal. It is not personalized and is kept separate from food targets.</MutedText>
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><AppButton label={workoutEditId ? 'Save changes' : 'Add workout'} icon="check" onPress={saveWorkout} testID="button-save-workout" /></View>
            <View style={{ flex: 1 }}><AppButton label="Cancel" tone="outline" onPress={resetWorkout} testID="button-cancel-workout" /></View>
          </View>
        </Card>
      ) : null}

      <Card>
        <SectionTitle title="Food & drink today" right={<LabelPill>{todayFoodEntries.length} entries</LabelPill>} />
        {todayFoodEntries.length === 0 ? <MutedText>No food entries today yet. Saved quick meals are above.</MutedText> : todayFoodEntries.map((entry) => (
          <View key={entry.id} testID={`row-food-${entry.id}`} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, gap: 7 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>{entry.name}</Text>
                <MutedText>{entry.meal} · {entry.time}</MutedText>
              </View>
              <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 14 }}>{entry.calories} kcal</Text>
              <IconButton icon="edit-2" label={`Edit ${entry.name}`} onPress={() => editFood(entry)} testID={`button-edit-food-${entry.id}`} />
              <IconButton icon="trash-2" label={`Delete ${entry.name}`} destructive onPress={() => confirmDeleteFood(entry)} testID={`button-delete-food-${entry.id}`} />
            </View>
            <MutedText>{entry.protein} g protein · {entry.carbs} g carbs · {entry.fat} g fat</MutedText>
            <View style={{ alignSelf: 'flex-start' }}>
              {foodPresets.some((preset) => preset.name.trim().toLowerCase() === entry.name.trim().toLowerCase() && preset.meal === entry.meal) ? (
                <LabelPill>Saved as quick meal</LabelPill>
              ) : (
                <AppButton label="Save as quick meal" icon="bookmark" tone="outline" onPress={() => savePreset(entry)} testID={`button-save-food-preset-${entry.id}`} />
              )}
            </View>
            {entry.source !== 'manual' ? <LabelPill>{sourceLabel[entry.source]}</LabelPill> : null}
          </View>
        ))}
      </Card>

      <Card>
        <SectionTitle title="Movement today" right={<LabelPill>{todayWorkoutEntries.length} entries</LabelPill>} />
        {todayWorkoutEntries.length === 0 ? <MutedText>No workouts logged today yet. A short walk counts too.</MutedText> : todayWorkoutEntries.map((entry) => (
          <View key={entry.id} testID={`row-workout-${entry.id}`} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12, gap: 7 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 15 }}>{entry.name}</Text>
                <MutedText>{entry.durationMinutes} min · {entry.effort} effort</MutedText>
              </View>
              <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 13 }}>~{entry.caloriesBurnedEstimate} kcal</Text>
              <IconButton icon="edit-2" label={`Edit ${entry.name}`} onPress={() => editWorkout(entry)} testID={`button-edit-workout-${entry.id}`} />
              <IconButton icon="trash-2" label={`Delete ${entry.name}`} destructive onPress={() => confirmDeleteWorkout(entry)} testID={`button-delete-workout-${entry.id}`} />
            </View>
            {entry.exercises.map((exercise, index) => (
              <MutedText key={`${entry.id}-exercise-${index}`}>
                {exercise.name}{exercise.sets || exercise.reps ? ` · ${exercise.sets} sets × ${exercise.reps} reps` : ''}{exercise.weight > 0 ? ` · ${exercise.weight} lb` : ''}
              </MutedText>
            ))}
          </View>
        ))}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Feather name="info" size={15} color={colors.mutedForeground} />
          <MutedText>Burn estimates are rough and are not subtracted from food totals.</MutedText>
        </View>
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <View style={{ flex: 1, gap: 4 }}>
            <SectionTitle title="Past entries" />
            <MutedText>{pastEntryCount} food and workout entries from earlier days are kept in your history.</MutedText>
          </View>
          <AppButton label={showHistory ? 'Hide' : 'Show'} icon={showHistory ? 'chevron-up' : 'chevron-down'} tone="outline" onPress={() => setShowHistory((current) => !current)} testID="button-toggle-log-history" />
        </View>
        {showHistory ? pastEntryCount === 0 ? (
          <MutedText>No earlier entries yet. Today’s entries will appear here after midnight.</MutedText>
        ) : (
          <View style={{ gap: 12 }}>
            {pastFoodEntries.map((entry) => (
              <View key={`history-food-${entry.id}`} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 10 }}>
                <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 14 }}>{entry.name}</Text>
                <MutedText>{dateLabel(entry.dateKey)} · {entry.meal} · {entry.time} · {entry.calories} kcal</MutedText>
              </View>
            ))}
            {pastWorkoutEntries.map((entry) => (
              <View key={`history-workout-${entry.id}`} style={{ borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 10 }}>
                <Text style={{ color: colors.foreground, fontFamily: 'DMSans_700Bold', fontSize: 14 }}>{entry.name}</Text>
                <MutedText>{dateLabel(entry.dateKey)} · {entry.durationMinutes} min · {entry.exercises.length} exercises</MutedText>
              </View>
            ))}
          </View>
        ) : null}
      </Card>
    </AppScreen>
  );
}
