import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { AppButton, AppScreen, Card, ChoiceChip, Field, MutedText, ProgressBar, SectionTitle } from '@/components/ui';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const goals = ['Build consistent habits', 'Improve nutrition', 'Get stronger', 'Manage weight'];
const experiences = ['New to exercise', 'Returning / occasional', 'Regular routine'];
const routines = ['Track my current routine', 'Help me adapt my routine', 'Create a beginner plan'];
const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const equipmentOptions = ['Bodyweight', 'Dumbbells', 'Resistance bands', 'Gym access'];
const steps = ['Your goal', 'Your experience', 'Your week', 'Nutrition targets'];

export default function OnboardingScreen() {
  const colors = useColors();
  const { profile, targets, updateProfile, updateTargets, completeOnboarding } = useAppState();
  const [step, setStep] = useState(0);

  const finish = () => {
    completeOnboarding();
    router.replace('/(tabs)');
  };

  const toggleList = (list: string[], value: string, update: (next: string[]) => void) => {
    update(list.includes(value) ? list.filter((item) => item !== value) : [...list, value]);
  };

  return (
    <AppScreen
      eyebrow={`GETTING STARTED · ${step + 1} OF ${steps.length}`}
      title="Let’s make this yours."
      subtitle="A few optional details help shape your first week. You can change them later."
    >
      <View style={{ gap: 8 }}>
        <ProgressBar value={step + 1} max={steps.length} />
        <MutedText>{steps[step]}</MutedText>
      </View>

      {step === 0 ? (
        <Card>
          <SectionTitle title="What matters most right now?" />
          <MutedText>Pick one starting point. This is a preference, not a score.</MutedText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
            {goals.map((goal) => <ChoiceChip key={goal} label={goal} selected={profile.goal === goal} onPress={() => updateProfile({ goal })} testID={`onboarding-goal-${goals.indexOf(goal)}`} />)}
          </View>
        </Card>
      ) : null}

      {step === 1 ? (
        <>
          <Card>
            <SectionTitle title="How would you describe your fitness experience?" />
            <MutedText>Choose the answer that feels right today. You can update it any time.</MutedText>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
              {experiences.map((experience) => <ChoiceChip key={experience} label={experience} selected={profile.experience === experience} onPress={() => updateProfile({ experience })} testID={`onboarding-experience-${experiences.indexOf(experience)}`} />)}
            </View>
          </Card>
          <Card>
            <SectionTitle title="What do you want help with?" />
            <View style={{ gap: 9 }}>
              {routines.map((routine) => <ChoiceChip key={routine} label={routine} selected={profile.routineMode === routine} onPress={() => updateProfile({ routineMode: routine })} testID={`onboarding-routine-${routines.indexOf(routine)}`} />)}
            </View>
          </Card>
        </>
      ) : null}

      {step === 2 ? (
        <>
          <Card>
            <SectionTitle title="When do you usually have time?" />
            <MutedText>Select as many days as you like. Plans stay flexible.</MutedText>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
              {days.map((day) => <ChoiceChip key={day} label={day.slice(0, 3)} selected={profile.daysAvailable.includes(day)} onPress={() => toggleList(profile.daysAvailable, day, (daysAvailable) => updateProfile({ daysAvailable }))} testID={`onboarding-day-${day.toLowerCase()}`} />)}
            </View>
          </Card>
          <Card>
            <SectionTitle title="What equipment can you use?" />
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>
              {equipmentOptions.map((item) => <ChoiceChip key={item} label={item} selected={profile.equipment.includes(item)} onPress={() => toggleList(profile.equipment, item, (equipment) => updateProfile({ equipment }))} testID={`onboarding-equipment-${equipmentOptions.indexOf(item)}`} />)}
            </View>
            <Field label="Anything you want a plan to work around? (optional)" value={profile.movementNotes} onChangeText={(movementNotes) => updateProfile({ movementNotes })} placeholder="Only share what you want the app to consider" multiline testID="onboarding-movement-notes" />
          </Card>
        </>
      ) : null}

      {step === 3 ? (
        <Card>
          <SectionTitle title="Set nutrition targets if you already have them" />
          <MutedText>These are optional and user-set. You can start logging without entering body measurements or nutrition targets.</MutedText>
          <Field label="Calories (kcal)" value={targets.calories > 0 ? String(targets.calories) : ''} onChangeText={(text) => updateTargets({ calories: text.trim() ? Math.max(0, Number(text) || 0) : 0 })} keyboardType="number-pad" placeholder="Optional" testID="onboarding-target-calories" />
          <View style={{ flexDirection: 'row', gap: 9 }}>
            <View style={{ flex: 1 }}><Field label="Protein (g)" value={targets.protein > 0 ? String(targets.protein) : ''} onChangeText={(text) => updateTargets({ protein: text.trim() ? Math.max(0, Number(text) || 0) : 0 })} keyboardType="number-pad" placeholder="Optional" testID="onboarding-target-protein" /></View>
            <View style={{ flex: 1 }}><Field label="Carbs (g)" value={targets.carbs > 0 ? String(targets.carbs) : ''} onChangeText={(text) => updateTargets({ carbs: text.trim() ? Math.max(0, Number(text) || 0) : 0 })} keyboardType="number-pad" placeholder="Optional" testID="onboarding-target-carbs" /></View>
          </View>
          <Field label="Fat (g)" value={targets.fat > 0 ? String(targets.fat) : ''} onChangeText={(text) => updateTargets({ fat: text.trim() ? Math.max(0, Number(text) || 0) : 0 })} keyboardType="number-pad" placeholder="Optional" testID="onboarding-target-fat" />
        </Card>
      ) : null}

      <Card style={{ backgroundColor: colors.secondary, borderColor: colors.secondary }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Feather name="shield" size={17} color={colors.primary} />
          <MutedText style={{ flex: 1 }}>Your setup stays on this device in this draft. Nothing here is a medical assessment.</MutedText>
        </View>
      </Card>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        {step > 0 ? <View style={{ flex: 1 }}><AppButton label="Back" icon="arrow-left" tone="outline" onPress={() => setStep((current) => Math.max(0, current - 1))} testID="button-onboarding-back" /></View> : null}
        {step < steps.length - 1 ? (
          <View style={{ flex: 1 }}><AppButton label="Continue" icon="arrow-right" onPress={() => setStep((current) => Math.min(steps.length - 1, current + 1))} testID="button-onboarding-next" /></View>
        ) : (
          <View style={{ flex: 1 }}><AppButton label="Start tracking" icon="check" onPress={finish} testID="button-onboarding-finish" /></View>
        )}
      </View>
      <AppButton label="Skip setup for now" tone="soft" onPress={finish} testID="button-onboarding-skip" />
    </AppScreen>
  );
}
