import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { router } from 'expo-router';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

export default function EntryRoute() {
  const { ready, hasCompletedOnboarding } = useAppState();
  const colors = useColors();

  useEffect(() => {
    if (!ready) return;
    router.replace(hasCompletedOnboarding ? '/(tabs)' : '/onboarding');
  }, [ready, hasCompletedOnboarding]);

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator color={colors.primary} />
    </View>
  );
}
