import { Router, type IRouter } from "express";
import healthRouter from "./health";
import habitFuelRouter from "./habit-fuel";

const router: IRouter = Router();

router.use(healthRouter);
router.use(habitFuelRouter);

export default router;
