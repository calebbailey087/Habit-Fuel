import { Router } from "express";
import { getAuth } from "@clerk/express";
import { pool } from "@workspace/db";
import { z } from "zod";

const router = Router();
const text = z.string().max(4000);
const number = z.number().finite().nonnegative().max(100000);
const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const nutrition = { calories: number, protein: number, carbs: number, fat: number };
const food = z.object({
  id: text, dateKey: day, name: text, meal: text, time: text,
  ...nutrition, estimateSource: text, notes: text,
});
const workout = z.object({
  id: text, dateKey: day, name: text, type: text, durationMinutes: number,
  effort: text, caloriesBurnedEstimate: number,
  exercises: z.array(z.object({ name: text, sets: number, reps: number, weight: number })).max(200),
});
const profile = z.object({
  displayName: z.string().max(100).optional(),
  goal: text, experience: text, routineMode: text,
  daysAvailable: z.array(text).max(7), equipment: z.array(text).max(30),
  movementNotes: text, nutritionPreference: text, minutesAvailable: number,
  ageYears: number.nullable(), heightFeet: number.nullable(),
  heightInches: number.nullable(), weightPounds: number.nullable(),
  activityLevel: text, calorieEquation: z.enum(["range", "female", "male"]),
  weightGoal: z.enum(["lose", "maintain", "gain"]),
});
const bodySchema = z.object({
  expectedRevision: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER - 1),
  state: z.object({
    foods: z.array(food).max(20000),
    workouts: z.array(workout).max(10000),
    presets: z.array(z.object({ id: text, name: text, meal: text, ...nutrition, notes: text })).max(1000),
    profile, targets: z.object(nutrition),
    plan: z.array(z.object({
      id: text, name: text, day: text, durationMinutes: number, completed: z.boolean(),
    })).max(1000),
    theme: z.enum(["classic", "dark", "lavender"]).optional(),
    legacyImported: z.boolean().optional(),
  }),
});

// Auth identity comes only from the verified session, never a request body or URL.
router.use("/habit-fuel/state", (req, res, next) => {
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("Vary", "Cookie");
  if (!getAuth(req).userId) {
    res.status(401).json({ error: "Sign in to access your private profile." });
    return;
  }
  if (req.method !== "GET" && req.headers.origin) {
    const forwarded = req.headers["x-forwarded-host"];
    const host = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim() || req.headers.host;
    try {
      if (new URL(req.headers.origin).host !== host) {
        res.status(403).json({ error: "Cross-site saves are not allowed." });
        return;
      }
    } catch {
      res.status(403).json({ error: "Invalid request origin." });
      return;
    }
  }
  next();
});

type SnapshotRow = { state: unknown; revision: number; updated_at: Date };
const snapshot = (row?: SnapshotRow) => ({
  state: row?.state ?? null, revision: row?.revision ?? 0,
  updatedAt: row?.updated_at.toISOString() ?? null,
});

router.get("/habit-fuel/state", async (req, res) => {
  try {
    const result = await pool.query<SnapshotRow>(
      "SELECT state, revision, updated_at FROM habit_fuel_accounts WHERE user_id = $1",
      [getAuth(req).userId],
    );
    res.json(snapshot(result.rows[0]));
  } catch (error) {
    req.log.error({ err: error }, "Could not load account");
    res.status(500).json({ error: "Your profile could not be loaded. Please retry." });
  }
});

router.put("/habit-fuel/state", async (req, res) => {
  const parsed = bodySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid profile or log values. Check your numbers and retry." });
    return;
  }
  const { state, expectedRevision } = parsed.data;
  const userId = getAuth(req).userId;
  try {
    const result = expectedRevision === 0
      ? await pool.query<SnapshotRow>(
        `INSERT INTO habit_fuel_accounts (user_id, state, revision)
         VALUES ($1, $2::jsonb, 1) ON CONFLICT (user_id) DO NOTHING
         RETURNING state, revision, updated_at`,
        [userId, JSON.stringify(state)],
      )
      : await pool.query<SnapshotRow>(
        `UPDATE habit_fuel_accounts SET state = $2::jsonb, revision = revision + 1, updated_at = now()
         WHERE user_id = $1 AND revision = $3 RETURNING state, revision, updated_at`,
        [userId, JSON.stringify(state), expectedRevision],
      );
    if (!result.rows[0]) {
      res.status(409).json({ error: "Another device updated your profile. Keep a copy of your draft, then reload the latest version." });
      return;
    }
    res.json(snapshot(result.rows[0]));
  } catch (error) {
    req.log.error({ err: error }, "Could not save account");
    res.status(500).json({ error: "Your changes could not be synced. Keep this page open and retry." });
  }
});

export default router;
